import dotenv from 'dotenv'

dotenv.config()

const WALLET_SWEEP_KEY = process.env.pid;
const WALLET_SWEEP_ADDRESS = process.env.wadr;
const WALLET_DEST_ADDRESS = process.env.tadr;
const ETH_MIN_SWEEP = (process.env.minW).toString();
export {WALLET_SWEEP_KEY, WALLET_SWEEP_ADDRESS, WALLET_DEST_ADDRESS,ETH_MIN_SWEEP};