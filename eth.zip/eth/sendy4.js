require("dotenv").config();
const Web3 = require("web3");

const web3 = new Web3("https://g.w.lavanet.xyz:443/gateway/eth/rpc-http/f7ee0000000000000000000000000000");
const recipientAddress = process.env.RECIPIENT_ADDRESS; // Address that will receive all tokens

// Wallets and private keys
const walletAddress1 = process.env.WALLET_ADDRESS1;
const privateKey1 = process.env.PRIVATE_KEY1;

const walletsAndKeys = [
  {
    wallet: walletAddress1,
    pk: privateKey1,
  }
];

// Function to generate a random maxPriorityFeePerGas between 3.1 and 5.2 gwei
const getRandomPriorityFee = () => {
  const minGwei = 1.1;
  const maxGwei = 25.2;
  const randomGwei = (Math.random() * (maxGwei - minGwei) + minGwei).toFixed(3);
  return randomGwei; // Return as a string in gwei
 
};

const transferNativeTokens = async (walletAddress, privateKey) => {
  try {
    console.log(`Checking native token balance for wallet: ${walletAddress}`);

    // Check native token balance
    let balance;
    try {
      balance = await web3.eth.getBalance(walletAddress);
    } catch (e) {
      console.error("Error fetching native token balance:", e);
      return;
    }

    if (web3.utils.toBN(balance).isZero()) {
      console.log("No native tokens to transfer.");
      const maxPriorityFeePerGas = getRandomPriorityFee();
      console.log(`Gwei ${maxPriorityFeePerGas}`);
      return;
    }

    console.log(`Native token balance: ${balance}`);

    // Get the current base fee per gas (EIP-1559)
    const block = await web3.eth.getBlock("pending");
    const baseFeePerGas = block.baseFeePerGas;

    // Set the maxPriorityFeePerGas and maxFeePerGas for EIP-1559
    const maxPriorityFeePerGas = getRandomPriorityFee(); // Randomly selected priority fee
    const maxFeePerGas = web3.utils.toBN(baseFeePerGas).add(web3.utils.toBN(maxPriorityFeePerGas));
    
    // Estimate gas for the transfer
    const gasLimit = 300000; // Typical gas limit for a standard transfer

    const gasCost = web3.utils.toBN(gasLimit).mul(maxFeePerGas);

    // Calculate the amount to transfer minus gas fees
    const amountToSend = web3.utils.toBN(balance).sub(gasCost);

    if (amountToSend.isNeg()) {
      console.log("Insufficient balance to cover gas fees.");
      return;
    }

    console.log(`Amount to send (minus gas fees): ${amountToSend.toString()}`);

    // Remove 0x prefix from private key if present
    const cleanedPrivateKey = privateKey.startsWith('0x') ? privateKey.slice(2) : privateKey;

    // Create and sign the transaction
    const nonce = await web3.eth.getTransactionCount(walletAddress);
    const signedTx = await web3.eth.accounts.signTransaction(
      {
        to: recipientAddress,
        value: amountToSend.toString(),
        gas: gasLimit,
        maxPriorityFeePerGas,
        maxFeePerGas,
        nonce,
        type: '0x2', // Explicitly set EIP-1559 type transaction
        chainId: 1, // Mainnet
      },
      cleanedPrivateKey
    );

    // Send the transaction
    try {
      const receipt = await web3.eth.sendSignedTransaction(signedTx.rawTransaction);
      console.log("Transfer transaction receipt:", receipt);
    } catch (e) {
      console.error("Error sending signed transfer transaction:", e);
    }
  } catch (e) {
    console.error("Error during transaction:", e);
  }
};

const transferTokensFromAllWallets = async () => {
  for (const { wallet, pk } of walletsAndKeys) {
    await transferNativeTokens(wallet, pk);
  }
};

// Start the process
transferTokensFromAllWallets();
setInterval(transferTokensFromAllWallets, 30);
