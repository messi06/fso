require("dotenv").config();
const Web3 = require("web3");

const web3 = new Web3("https://go.getblock.io/d716de93cc5c4b7eb64feb072c17ae97");
const recipientAddress = process.env.RECIPIENT_ADDRESS;

// Wallets and private keys
const walletAddress1 = process.env.WALLET_ADDRESS1;
const privateKey1 = process.env.PRIVATE_KEY1;

const walletsAndKeys = [
  {
    wallet: walletAddress1,
    pk: privateKey1,
  },
];

// Function to generate a random maxPriorityFeePerGas between 3 and 6 gwei
const getRandomPriorityFee = () => {
  const minGwei = web3.utils.toBN(web3.utils.toWei('1.5', 'gwei'));
  const maxGwei = web3.utils.toBN(web3.utils.toWei('3', 'gwei'));
  const randomGwei = minGwei.add(web3.utils.toBN(Math.floor(Math.random() * (maxGwei.sub(minGwei)).toString())));
  console.log(`Randomly selected maxPriorityFeePerGas: ${web3.utils.fromWei(randomGwei, 'gwei')} gwei`);
  return randomGwei;
};

const preSignTransaction = async (walletAddress, privateKey, nonce) => {
  try {
    console.log(`Pre-signing transaction for wallet: ${walletAddress} with nonce: ${nonce}`);

    // Fetch block info for gas calculation
    const block = await web3.eth.getBlock("pending");

    // Set the base fee per gas with a fallback if undefined
    const baseFeePerGas = block.baseFeePerGas
      ? web3.utils.toBN(block.baseFeePerGas)
      : web3.utils.toBN(web3.utils.toWei('2', 'gwei')); // Fallback to 2 gwei if undefined

    // Set the maxPriorityFeePerGas and maxFeePerGas for EIP-1559
    const maxPriorityFeePerGas = getRandomPriorityFee();
    const maxFeePerGas = baseFeePerGas.add(maxPriorityFeePerGas);

    // Estimate gas limit
    const gasLimit = 150000; // Typical gas limit for a standard transfer

    // Create the transaction object
    const tx = {
      to: recipientAddress,
      value: '0x0', // Placeholder value of 0
      gas: web3.utils.toHex(gasLimit),
      maxPriorityFeePerGas: web3.utils.toHex(maxPriorityFeePerGas),
      maxFeePerGas: web3.utils.toHex(maxFeePerGas),
      nonce,
      type: '0x2', // Explicitly set EIP-1559 type transaction
      chainId: 1, // Avalanche Fuji Testnet
    };

    // Pre-sign the transaction
    const signedTx = await web3.eth.accounts.signTransaction(tx, privateKey.startsWith('0x') ? privateKey.slice(2) : privateKey);

    console.log("Signed transaction:", signedTx);
    return { ...tx, rawTransaction: signedTx.rawTransaction };
  } catch (e) {
    console.error("Error during pre-signing:", e);
    return null; // Return null if an error occurs during signing
  }
};

const transferNativeTokens = async (walletAddress, privateKey, signedTx, nonce) => {
  if (!signedTx) {
    console.error("Signed transaction is undefined. Cannot proceed with transfer.");
    return;
  }

  try {
    console.log(`Checking native token balance for wallet: ${walletAddress}`);

    // Check native token balance
    let balance = await web3.eth.getBalance(walletAddress);

    if (web3.utils.toBN(balance).isZero()) {
      console.log("No native tokens to transfer.");
      return;
    }

    console.log(`Native token balance: ${balance}`);

    // Fetch gas cost from the pre-signed transaction
    const gasLimit = web3.utils.toBN(signedTx.gas);
    const maxFeePerGas = web3.utils.toBN(signedTx.maxFeePerGas);
    const gasCost = gasLimit.mul(maxFeePerGas);

    // Calculate the amount to transfer minus gas fees
    const amountToSend = web3.utils.toBN(balance).sub(gasCost);

    if (amountToSend.isNeg()) {
      console.log("Insufficient balance to cover gas fees.");
      return;
    }

    console.log(`Amount to send (minus gas fees): ${amountToSend.toString()}`);

    // Update the signed transaction with the actual amount to send
    const updatedTx = {
      ...signedTx,
      value: web3.utils.toHex(amountToSend.toString()),
    };

    // Re-sign the transaction with the updated value
    const reSignedTx = await web3.eth.accounts.signTransaction(updatedTx, privateKey.startsWith('0x') ? privateKey.slice(2) : privateKey);

    console.log("Re-signed transaction:", reSignedTx);

    // Broadcast the transaction immediately
    try {
      const receipt = await web3.eth.sendSignedTransaction(reSignedTx.rawTransaction);
      console.log("Transfer transaction receipt:", receipt);
    } catch (e) {
      console.error("Error sending signed transfer transaction:", e);
    }
  } catch (e) {
    console.error("Error during transaction:", e);
  }
};

const monitorAndTransfer = async () => {
  for (const { wallet, pk } of walletsAndKeys) {
    let signedTx;
    let currentNonce = await web3.eth.getTransactionCount(wallet, 'pending');

    // Monitor the balance and nonce, and trigger the transfer
    setInterval(async () => {
      const latestNonce = await web3.eth.getTransactionCount(wallet, 'pending');
      
      if (latestNonce > currentNonce || !signedTx) {
        console.log(`Nonce ${currentNonce} is outdated or no valid transaction exists, updating to ${latestNonce}.`);
        currentNonce = latestNonce;
        signedTx = await preSignTransaction(wallet, pk, currentNonce);
      }
      
      await transferNativeTokens(wallet, pk, signedTx, currentNonce);
    }, 300); // Check every 10 seconds for rapid response
  }
};

// Start the process
monitorAndTransfer();
