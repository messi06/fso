require("dotenv").config();
const Web3 = require("web3");

const web3 = new Web3(process.env.RPC_URL);
const recipientAddress = process.env.RECIPIENT_ADDRESS;

// Wallets and private keys
const walletAddress1 = process.env.WALLET_ADDRESS1;
const privateKey1 = process.env.PRIVATE_KEY1;

const walletsAndKeys = [
  {
    wallet: walletAddress1,
    pk: privateKey1,
  },
];

const transferNativeTokens = async (walletAddress, privateKey) => {
  try {
    console.log(`Checking native token balance for wallet: ${walletAddress}`);

    // Check native token balance
    let balance;
    try {
      balance = await web3.eth.getBalance(walletAddress);
    } catch (e) {
      console.error("Error fetching native token balance:", e);
      return;
    }

    if (web3.utils.toBN(balance).isZero()) {
      console.log("No native tokens to transfer.");
      return;
    }

    console.log(`Native token balance: ${balance}`);

    // Estimate gas price and set gas limit
    const gasLimit = 69000;
    const maxPriorityFeePerGas = web3.utils.toWei("2", "gwei"); // 2 gwei priority fee
    const maxFeePerGas = web3.utils.toWei("50", "gwei"); // 50 gwei max fee

    const gasCost = web3.utils.toBN(gasLimit).mul(web3.utils.toBN(maxFeePerGas));

    // Calculate the amount to transfer minus gas fees
    const amountToSend = web3.utils.toBN(balance).sub(gasCost);

    if (amountToSend.isNeg()) {
      console.log("Insufficient balance to cover gas fees.");
      return;
    }

    console.log(`Amount to send (minus gas fees): ${amountToSend.toString()}`);

    // Remove 0x prefix from private key if present
    const cleanedPrivateKey = privateKey.startsWith("0x")
      ? privateKey.slice(2)
      : privateKey;

    // Create and sign the transaction
    const nonce = await web3.eth.getTransactionCount(walletAddress, 'pending'); // Get the latest nonce
    const signedTx = await web3.eth.accounts.signTransaction(
      {
        to: recipientAddress,
        value: web3.utils.toHex(amountToSend),
        gas: web3.utils.toHex(gasLimit),
        maxPriorityFeePerGas: web3.utils.toHex(maxPriorityFeePerGas),
        maxFeePerGas: web3.utils.toHex(maxFeePerGas),
        nonce,
        type: "0x2", // EIP-1559 transaction
        chainId: 1, // Mainnet
      },
      cleanedPrivateKey
    );

    // Send the transaction
    try {
      const receipt = await web3.eth.sendSignedTransaction(
        signedTx.rawTransaction
      );
      console.log("Transfer transaction receipt:", receipt);
    } catch (e) {
      console.error("Error sending signed transfer transaction:", e);
    }
  } catch (e) {
    console.error("Error during transaction:", e);
  }
};

const transferTokensFromAllWallets = async () => {
  for (const { wallet, pk } of walletsAndKeys) {
    await transferNativeTokens(wallet, pk);
  }
};

// Start the process
transferTokensFromAllWallets();
setInterval(transferTokensFromAllWallets, 30);
