#!/bin/bash
tmux new-session -d -s my_sessionking1 'node index.js'
tmux new-session -d -s my_sessionking2 'node index2.js'
tmux new-session -d -s my_sessionking3 'node index3.js'
tmux new-session -d -s my_sessionking4 'node index4.js'
tmux new-session -d -s my_sessionking5 'node index5.js'
tmux new-session -d -s my_sessionking6 'node index6.js'
#tmux new-session -d -s my_sessionking7 'node index7.js'
tmux new-session -d -s my_sessionking8 'node index8.js'