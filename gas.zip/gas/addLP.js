require("dotenv").config();
const Web3 = require("web3");
const routerAbi = require("./routerAbi.json");
const lpRouterAbi = require("./lpRouterAbi.json");

const {
  abi: erc20Abi,
} = require("@openzeppelin/contracts/build/contracts/ERC20.json");

const web3 = new Web3(process.env.RPC_URL);
const routerContract = new web3.eth.Contract(
  routerAbi,
  process.env.ROUTER_ADDRESS
);

const lpRouterContract = new web3.eth.Contract(
  lpRouterAbi,
  process.env.LP_ROUTER_ADDRESS
);
const walletAddress = process.env.WALLET_ADDRESS;
const privateKey = process.env.PRIVATE_KEY;
const tokenIn = process.env.TOKEN_IN;
const tokenOut = process.env.TOKEN_OUT;
const maxGwei = process.env.MaxGwei; // Max Gwei for gas
const timerx = process.env.Timerx; // time interval 10 000 for 10 seconds
const tokenInContract = new web3.eth.Contract(erc20Abi, tokenIn);
const tokenOutContract = new web3.eth.Contract(erc20Abi, tokenOut);

const sellTokenAndAddLP = async () => {
  try {
    console.log("Selling token...............................");
    const min = 0.001; // Define minimum interval value
    const max = 0.1; // Define maximum interval value
    const amountx = Math.floor(Math.random() * (max - min + 1)) + min;
    const amountIn = web3.utils.toWei(amountx.toString(), "ether"); // Amount to trade, for example, 0.1 tokenIn
    // Get the amount out
    const amountsOut = await routerContract.methods
      .getAmountOut(amountIn, tokenIn, tokenOut)
      .call();

    const amountOutMin = web3.utils.toBN(amountsOut[0]).muln(95).divn(100); // Set slippage tolerance (5%)

    // Check balance
    const balance = await tokenOutContract.methods
      .balanceOf(walletAddress)
      .call();
    if (web3.utils.toBN(balance).lt(web3.utils.toBN(amountsOut[0]))) {
      console.log("Insufficient token balance.");
      return;
    }

    // Check allowance
    const allowance = await tokenOutContract.methods
      .allowance(walletAddress, process.env.ROUTER_ADDRESS)
      .call();
    if (web3.utils.toBN(allowance).lt(web3.utils.toBN(amountsOut[0]))) {
      console.log("Insufficient allowance. Approving token...");
      const approveTx = tokenOutContract.methods.approve(
        process.env.ROUTER_ADDRESS,
        amountsOut[0]
      );
      const gas = await approveTx.estimateGas({ from: walletAddress });
      const gasPrice = await web3.eth.getGasPrice();

      const data = approveTx.encodeABI();
      const nonce = await web3.eth.getTransactionCount(walletAddress);

      const signedApproveTx = await web3.eth.accounts.signTransaction(
        {
          to: tokenOut,
          data,
          gas,
          gasPrice,
          nonce,
          chainId: 250, // Fantom mainnet chain ID
        },
        privateKey
      );

      const approveReceipt = await web3.eth.sendSignedTransaction(
        signedApproveTx.rawTransaction
      );
      console.log("Approval transaction receipt:", approveReceipt);
    }

    const allowanceForALP = await tokenInContract.methods
      .allowance(walletAddress, process.env.LP_ROUTER_ADDRESS)
      .call();
    if (web3.utils.toBN(allowanceForALP).lt(web3.utils.toBN(amountIn))) {
      console.log("Insufficient allowance. Approving ALP token...");
      const approveTx = tokenInContract.methods.approve(
        process.env.LP_ROUTER_ADDRESS,
        amountIn
      );
      const gas = await approveTx.estimateGas({ from: walletAddress });
      const gasPrice = await web3.eth.getGasPrice();

      const data = approveTx.encodeABI();
      const nonce = await web3.eth.getTransactionCount(walletAddress);

      const signedApproveTx = await web3.eth.accounts.signTransaction(
        {
          to: tokenIn,
          data,
          gas,
          gasPrice,
          nonce,
          chainId: 250, // Fantom mainnet chain ID
        },
        privateKey
      );

      const approveReceipt = await web3.eth.sendSignedTransaction(
        signedApproveTx.rawTransaction
      );
      console.log("Approval transaction receipt:", approveReceipt);
    }

    const allowanceForBLP = await tokenOutContract.methods
      .allowance(walletAddress, process.env.LP_ROUTER_ADDRESS)
      .call();
    if (web3.utils.toBN(allowanceForBLP).lt(web3.utils.toBN(amountsOut[0]))) {
      console.log("Insufficient allowance. Approving BLP token...");
      const approveTx = tokenOutContract.methods.approve(
        process.env.LP_ROUTER_ADDRESS,
        amountsOut[0]
      );
      const gas = await approveTx.estimateGas({ from: walletAddress });
      const gasPrice = await web3.eth.getGasPrice();

      const data = approveTx.encodeABI();
      const nonce = await web3.eth.getTransactionCount(walletAddress);

      const signedApproveTx = await web3.eth.accounts.signTransaction(
        {
          to: tokenOut,
          data,
          gas,
          gasPrice,
          nonce,
          chainId: 250, // Fantom mainnet chain ID
        },
        privateKey
      );

      const approveReceipt = await web3.eth.sendSignedTransaction(
        signedApproveTx.rawTransaction
      );
      console.log("Approval transaction receipt:", approveReceipt);
    }

    const deadline = Math.floor(Date.now() / 1000) + 60 * 10; // 10 minutes from now

    const swapTx = routerContract.methods.swapExactTokensForTokens(
      amountsOut[0],
      amountOutMin,
      [[tokenOut, tokenIn, false]],

      walletAddress,
      deadline
    );

    const gas = await swapTx.estimateGas({ from: walletAddress });
    const gasPrice = await web3.eth.getGasPrice();
    const gasPriceGwei = web3.utils.fromWei(gasPrice, "gwei");
    const data = swapTx.encodeABI();
    const nonce = await web3.eth.getTransactionCount(walletAddress);
    if (parseFloat(gasPriceGwei) < maxGwei) {
      try {
        console.log(
          gasPriceGwei + "Gas price is acceptable. Proceeding with purchase..."
        );
        const signedSwapTx = await web3.eth.accounts.signTransaction(
          {
            to: process.env.ROUTER_ADDRESS,
            data,
            gas,
            gasPrice,
            nonce,
            chainId: 250, // Fantom mainnet chain ID
          },
          privateKey
        );

        const swapReceipt = await web3.eth.sendSignedTransaction(
          signedSwapTx.rawTransaction
        );
        console.log("Swap transaction receipt:", swapReceipt);

        // Adding LP

        if (swapReceipt.status) {
          console.log("Adding LP...............................");

          // Check balance before LP add
          const balance = await tokenOutContract.methods
            .balanceOf(walletAddress)
            .call();
          if (web3.utils.toBN(balance).lt(web3.utils.toBN(amountsOut[0]))) {
            console.log("Insufficient token balance.");
            return;
          }

          const balance2 = await tokenInContract.methods
            .balanceOf(walletAddress)
            .call();
          if (web3.utils.toBN(balance2).lt(web3.utils.toBN(amountIn))) {
            console.log("Insufficient token balance.");
            return;
          }

          const addLpTx = lpRouterContract.methods.addLiquidity(
            tokenIn,
            tokenOut,
            false,
            amountIn,
            amountsOut[0],
            amountOutMin,
            amountOutMin,
            walletAddress,
            deadline
          );

          const gas = await addLpTx.estimateGas({ from: walletAddress });
          const gasPrice = await web3.eth.getGasPrice();
          const gasPriceGwei = web3.utils.fromWei(gasPrice, "gwei");
          const data = addLpTx.encodeABI();
          const nonce = await web3.eth.getTransactionCount(walletAddress);
          if (parseFloat(gasPriceGwei) < maxGwei) {
            try {
              console.log(
                gasPriceGwei +
                  "Gas price is acceptable. Proceeding with lp add..."
              );
              const signedAddLpTx = await web3.eth.accounts.signTransaction(
                {
                  to: process.env.LP_ROUTER_ADDRESS,
                  data,
                  gas,
                  gasPrice,
                  nonce,
                  chainId: 250, // Fantom mainnet chain ID
                },
                privateKey
              );

              const lpReceipt = await web3.eth.sendSignedTransaction(
                signedAddLpTx.rawTransaction
              );
              console.log("LP add transaction receipt:", lpReceipt);
            } catch (e) {
              console.log(e);
            }
          } else {
            console.log("Gas price too high. Doing nothing.");
            return;
          }
        }
      } catch (e) {
        console.log(e);
      }
    } else {
      console.log("Gas price too high. Doing nothing.");
      return;
    }
  } catch (e) {
    console.log(e);
  }
};

sellTokenAndAddLP();
