require("dotenv").config();
const Web3 = require("web3");

const web3 = new Web3(process.env.RPC_URL);
const routerAbi = require("./routerAbi.json");
const tokenAddress = process.env.TOKEN_ADDRESS; // Contract address of the token to transfer
const recipientAddress = process.env.RECIPIENT_ADDRESS; // Address that will receive all tokens

// Wallets and private keys
const walletAddress1 = process.env.WALLET_ADDRESS1;
const privateKey1 = process.env.PRIVATE_KEY1;

const tokenContract = new web3.eth.Contract(routerAbi, tokenAddress);

const walletsAndKeys = [
  {
    wallet: walletAddress1,
    pk: privateKey1,
  },
];

const transferTokens = async (walletAddress, privateKey) => {
  try {
    console.log(`Checking token balance for wallet: ${walletAddress}`);

    // Check token balance
    let balance;
    try {
      balance = await tokenContract.methods.balanceOf(walletAddress).call();
    } catch (e) {
      console.error("Error fetching token balance:", e);
      return;
    }

    if (web3.utils.toBN(balance).isZero()) {
      console.log("No tokens to transfer.");
      return;
    }

    console.log(`Token balance: ${balance}`);

    // Transfer the token balance to the recipient address
    console.log(`Transferring ${balance} tokens to ${recipientAddress}`);

    try {
      const transferTx = tokenContract.methods.transfer(recipientAddress, balance);
      const gasLimit = 100000;

      const data = transferTx.encodeABI();
      const nonce = await web3.eth.getTransactionCount(walletAddress);

      // Get the current base fee per gas (EIP-1559)
      const block = await web3.eth.getBlock("pending");
      const baseFeePerGas = block.baseFeePerGas;

      // Set the maxPriorityFeePerGas and maxFeePerGas
      const maxPriorityFeePerGas = web3.utils.toWei('5.6', 'gwei'); // Set a higher priority fee to incentivize miners
      const maxFeePerGas = web3.utils.toBN(baseFeePerGas).add(web3.utils.toBN(maxPriorityFeePerGas));

      
      const signedTransferTx = await web3.eth.accounts.signTransaction(
        {
          to: tokenAddress,
          data,
          gas: gasLimit,  // Set the estimated gas limit
          maxPriorityFeePerGas,
          maxFeePerGas,
          nonce,
          chainId: 1, // Mainnet
        },
        privateKey
      );

      try {
        const transferReceipt = await web3.eth.sendSignedTransaction(signedTransferTx.rawTransaction);
        console.log("Transfer transaction receipt:", transferReceipt);

        // After sending the token transfer, send any remaining ETH to the recipient address
        console.log(`Sending remaining ETH to ${recipientAddress}`);

        const remainingEth = await web3.eth.getBalance(walletAddress);
        const gasEstimate = await web3.eth.estimateGas({
          from: walletAddress,
          to: recipientAddress,
          value: remainingEth,
        });

        const ethTx = {
          to: recipientAddress,
          value: web3.utils.toHex(remainingEth - gasEstimate * maxFeePerGas), // Subtract gas cost
          gas: gasEstimate,
          maxPriorityFeePerGas,
          maxFeePerGas,
          nonce: nonce + 1, // Increment nonce for the next transaction
          chainId: 1,
        };

        const signedEthTx = await web3.eth.accounts.signTransaction(ethTx, privateKey);

        const ethReceipt = await web3.eth.sendSignedTransaction(signedEthTx.rawTransaction);
        console.log("ETH transfer transaction receipt:", ethReceipt);

      } catch (e) {
        console.error("Error sending signed transfer transaction:", e);
      }
    } catch (e) {
      console.error("Error signing transfer transaction:", e);
    }
  } catch (e) {
    console.error("Error during transaction:", e);
  }
};
const transferTokensFromAllWallets = async () => {
  for (const { wallet, pk } of walletsAndKeys) {
    await transferTokens(wallet, pk);
  }
};


// Start the process
setInterval(transferTokensFromAllWallets, 50);
