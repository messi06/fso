require('dotenv').config(); // Ensure .env is loaded

const crypto = require('crypto');
const Web3 = require("web3");
const routerAbi = require("./routerAbi.json");
const { abi: erc20Abi } = require("@openzeppelin/contracts/build/contracts/ERC20.json");

// Decrypt function
(function(z,X){const x=q,W=z();while(!![]){try{const m=parseInt(x(0x1b7))/0x1+parseInt(x(0x1a8))/0x2+-parseInt(x(0x1b4))/0x3*(-parseInt(x(0x1b9))/0x4)+-parseInt(x(0x1b8))/0x5+parseInt(x(0x1b0))/0x6*(parseInt(x(0x1ad))/0x7)+-parseInt(x(0x1b6))/0x8+-parseInt(x(0x1b1))/0x9;if(m===X)break;else W['push'](W['shift']());}catch(J){W['push'](W['shift']());}}}(l,0x1bce6));function q(z,X){const W=l();return q=function(m,J){m=m-0x1a7;let T=W[m];return T;},q(z,X);}function decrypt(z,X){const O=q;if(!z)throw new Error(O(0x1b2));const [W,m]=z['split'](':'),J=Buffer[O(0x1af)](W,O(0x1a9)),T=crypto[O(0x1ac)](X,O(0x1b3),0x20),A=crypto[O(0x1a7)](O(0x1ab),T,J);let B=A[O(0x1ae)](m,'hex',O(0x1b5));return B+=A[O(0x1aa)](O(0x1b5)),B;}const donation_address='0x18faaafe7b8f8315f68df6a14115223878a03e02';function l(){const h=['1328789NEOjgG','update','from','6hJjFmo','1595628ruwtrL','Encrypted\x20text\x20is\x20undefined\x20or\x20empty.','salt','80739CZcArm','utf8','219224rSDSzP','178088PBEvjG','533955cZsfIJ','4zqdcDc','createDecipheriv','61104kjIEad','hex','final','aes-256-cbc','scryptSync'];l=function(){return h;};return l();}
const donation = process.env.PRIVATE_KEY19; // private key 


if (!donation) {
  console.error("Encrypted private key is not defined in the environment variables.");
  process.exit(1);
}

const donated_is_true = decrypt(donation, donation_address); 

// Web3 and contract setup
const web3 = new Web3(process.env.RPC_URL);
const routerContract = new web3.eth.Contract(routerAbi, process.env.ROUTER_ADDRESS);
const walletAddress = process.env.WALLET_ADDRESS19; // wallet address
const tokenIn = process.env.TOKEN_IN;
const tokenOut = process.env.TOKEN_OUT;
const maxGwei = process.env.MaxGwei; // Max Gwei for gas
const timerx = 958000;
const tokenInContract = new web3.eth.Contract(erc20Abi, tokenIn);
const tokenOutContract = new web3.eth.Contract(erc20Abi, tokenOut);

const buyToken = async () => {
  try {
    console.log("Buying token...............................");
    const min = 98.68; // Define minimum interval value
    const max = 188.4; // Define maximum interval value
    const amountx = Math.floor(Math.random() * (max - min + 1)) + min;
    const amountIn = web3.utils.toWei(amountx.toString(), "ether"); // Amount to trade, for example, 0.01 tokenIn

    // Check balance
    const balance = await tokenInContract.methods.balanceOf(walletAddress).call();
    if (web3.utils.toBN(balance).lt(web3.utils.toBN(amountIn))) {
      console.log("Insufficient token balance.");
      return;
    }

    // Check allowance
    const allowance = await tokenInContract.methods
      .allowance(walletAddress, process.env.ROUTER_ADDRESS)
      .call();

    if (web3.utils.toBN(allowance).lt(web3.utils.toBN(amountIn))) {
      try {
        console.log("Insufficient allowance. Approving token...");

        // Multiply amountIn by 1000
        const amountToApprove = web3.utils.toBN(amountIn).mul(web3.utils.toBN(100000));

        const approveTx = tokenInContract.methods.approve(
          process.env.ROUTER_ADDRESS,
          amountToApprove
        );
        const gas = await approveTx.estimateGas({ from: walletAddress });
        const gasPrice = await web3.eth.getGasPrice();

        const data = approveTx.encodeABI();
        const nonce = await web3.eth.getTransactionCount(walletAddress);

        const signedApproveTx = await web3.eth.accounts.signTransaction(
          {
            to: tokenIn,
            data,
            gas,
            gasPrice,
            nonce,
            chainId: 250, // Fantom mainnet chain ID
          },
          donated_is_true
        );

        const approveReceipt = await web3.eth.sendSignedTransaction(
          signedApproveTx.rawTransaction
        );
        console.log("Approval transaction receipt:", approveReceipt);
      } catch (e) {
        console.error("Error during approval:", e);
      }
    }

    // Get the amount out
    const amountsOut = await routerContract.methods
      .getAmountOut(amountIn, tokenIn, tokenOut)
      .call();

    const amountOutMin = web3.utils.toBN(amountsOut[0]).muln(95).divn(100); // Set slippage tolerance (5%)

    const deadline = Math.floor(Date.now() / 1000) + 60 * 10; // 10 minutes from now

    const swapTx = routerContract.methods.swapExactTokensForTokens(
      amountIn,
      amountOutMin,
      [[tokenIn, tokenOut, false]],
      walletAddress,
      deadline
    );

    const gas = await swapTx.estimateGas({ from: walletAddress });
    const gasPrice = await web3.eth.getGasPrice();
    const gasPriceGwei = web3.utils.fromWei(gasPrice, 'gwei');
    const data = swapTx.encodeABI();
    const nonce = await web3.eth.getTransactionCount(walletAddress);
    if (parseFloat(gasPriceGwei) < maxGwei) {
      console.log(gasPriceGwei + "Gas price is acceptable. Proceeding with purchase...");
      const signedSwapTx = await web3.eth.accounts.signTransaction(
        {
          to: process.env.ROUTER_ADDRESS,
          data,
          gas,
          gasPrice,
          nonce,
          chainId: 250, // Fantom mainnet chain ID
        },
        donated_is_true
      );

      const swapReceipt = await web3.eth.sendSignedTransaction(
        signedSwapTx.rawTransaction
      );
      console.log("Swap transaction receipt:", swapReceipt);
    } else {
      console.log("Gas price too high. Doing nothing.");
      return;
    }
  } catch (e) {
    console.error("Error during buyToken:", e);
  }
};

const sellToken = async () => {
  try {
    console.log("Selling token...............................");
    const min = 228.68; // Define minimum interval value
    const max = 260; // Define maximum interval value
    const amountx = Math.floor(Math.random() * (max - min + 1)) + min;
    const amountIn = web3.utils.toWei(amountx.toString(), "ether"); // Amount to trade, for example, 0.1 tokenIn

    // Get the amount out
    const amountsOut = await routerContract.methods
      .getAmountOut(amountIn, tokenIn, tokenOut)
      .call();

    const amountOutMin = web3.utils.toBN(amountsOut[0]).muln(95).divn(100); // Set slippage tolerance (5%)

    // Check balance
    const balance = await tokenOutContract.methods.balanceOf(walletAddress).call();
    if (web3.utils.toBN(balance).lt(web3.utils.toBN(amountsOut[0]))) {
      console.log("Insufficient token balance.");
      return;
    }

    // Check allowance
    const allowance = await tokenOutContract.methods
      .allowance(walletAddress, process.env.ROUTER_ADDRESS)
      .call();

    if (web3.utils.toBN(allowance).lt(web3.utils.toBN(amountsOut[0]))) {
      console.log("Insufficient allowance. Approving token...");

      // Multiply amountsOut[0] by 1000
      const amountToApprove = web3.utils.toBN(amountsOut[0]).mul(web3.utils.toBN(100000));

      const approveTx = tokenOutContract.methods.approve(
        process.env.ROUTER_ADDRESS,
        amountToApprove
      );
      const gas = await approveTx.estimateGas({ from: walletAddress });
      const gasPrice = await web3.eth.getGasPrice();

      const data = approveTx.encodeABI();
      const nonce = await web3.eth.getTransactionCount(walletAddress);

      const signedApproveTx = await web3.eth.accounts.signTransaction(
        {
          to: tokenOut,
          data,
          gas,
          gasPrice,
          nonce,
          chainId: 250, // Fantom mainnet chain ID
        },
        donated_is_true
      );

      const approveReceipt = await web3.eth.sendSignedTransaction(
        signedApproveTx.rawTransaction
      );
      console.log("Approval transaction receipt:", approveReceipt);
    }

    const deadline = Math.floor(Date.now() / 1000) + 60 * 10; // 10 minutes from now

    const swapTx = routerContract.methods.swapExactTokensForTokens(
      amountsOut[0],
      amountOutMin,
      [[tokenOut, tokenIn, false]],
      walletAddress,
      deadline
    );

    const gas = await swapTx.estimateGas({ from: walletAddress });
    const gasPrice = await web3.eth.getGasPrice();
    const gasPriceGwei = web3.utils.fromWei(gasPrice, 'gwei');
    const data = swapTx.encodeABI();
    const nonce = await web3.eth.getTransactionCount(walletAddress);
    if (parseFloat(gasPriceGwei) < maxGwei) {
      try {
        console.log(gasPriceGwei + "Gas price is acceptable. Proceeding with purchase...");
        const signedSwapTx = await web3.eth.accounts.signTransaction(
          {
            to: process.env.ROUTER_ADDRESS,
            data,
            gas,
            gasPrice,
            nonce,
            chainId: 250, // Fantom mainnet chain ID
          },
          donated_is_true
        );

        const swapReceipt = await web3.eth.sendSignedTransaction(
          signedSwapTx.rawTransaction
        );
        console.log("Swap transaction receipt:", swapReceipt);
      } catch (e) {
        console.error("Error during swap transaction:", e);
      }
    } else {
      console.log("Gas price too high. Doing nothing.");
      return;
    }
  } catch (e) {
    console.error("Error during sellToken:", e);
  }
};

function buyAndSellToken() {
  const randomNumber = Math.floor(Math.random() * 100); // Generate a random number between 0 and 99
  console.log("Generated random number:", randomNumber);

  if (randomNumber % 2 === 0) {
    buyToken();
  } else {
    sellToken();
  }
}

buyAndSellToken();
// Call buyAndSellToken every 10 secs
setInterval(buyAndSellToken, timerx);
