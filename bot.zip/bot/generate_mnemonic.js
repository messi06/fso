const { ethers } = require("ethers");

const generateMenmonic = () => {
  const mnemonic = ethers.Wallet.createRandom().mnemonic.phrase;

  console.log(mnemonic);
};

const generateWalletsFromMnemonic = (mnemonic) => {
  // Validate the mnemonic phrase
  if (!ethers.utils.isValidMnemonic(mnemonic)) {
    throw new Error("Invalid mnemonic phrase");
  }

  const wallets = [];

  for (let i = 0; i < 30; i++) {
    // Derive the wallet from the mnemonic and the index
    const wallet = ethers.Wallet.fromMnemonic(mnemonic, `m/44'/60'/0'/0/${i}`);

    // Push the wallet address and private key to the wallets array
    wallets.push({
      address: wallet.address,
      privateKey: wallet.privateKey,
    });
  }

  return wallets;
};

const mnemonic =
  "gallery taxi virtual novel innocent remember echo lake shine solid increase cherry";
const wallets = generateWalletsFromMnemonic(mnemonic);

wallets.forEach((wallet, index) => {

  console.log(`WALLET_ADDRESS${index + 1}= ${wallet.address}`);
  console.log(`PRIVATE_KEY${index + 1}= ${wallet.privateKey}`);
});

// Uncomment to generate a new phrase
  //generateMenmonic();
