const { ethers } = require('ethers');
const crypto = require('crypto');

// Function to encrypt the private key using AES-256-CBC
function encrypt(text, secretPhrase) {
  const iv = crypto.randomBytes(16);
  const key = crypto.scryptSync(secretPhrase, 'salt', 32);
  const cipher = crypto.createCipheriv('aes-256-cbc', key, iv);
  let encrypted = cipher.update(text, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  return iv.toString('hex') + ':' + encrypted;
}

// Generate a random secret phrase for encryption
const generateSecretPhrase = () => {
  return crypto.randomBytes(32).toString('hex');
};

// Function to generate a new mnemonic phrase
const generateMnemonic = () => {
  return ethers.Wallet.createRandom().mnemonic.phrase;
};

// Function to derive wallet addresses and private keys from a mnemonic phrase
const generateWalletsFromMnemonic = (mnemonic) => {
  if (!ethers.utils.isValidMnemonic(mnemonic)) {
    throw new Error("Invalid mnemonic phrase");
  }

  const wallets = [];
  const hdNode = ethers.utils.HDNode.fromMnemonic(mnemonic);

  for (let i = 0; i < 30; i++) {
    const wallet = hdNode.derivePath(`m/44'/60'/0'/0/${i}`);
    wallets.push({
      address: wallet.address,
      privateKey: wallet.privateKey,
    });
  }

  return wallets;
};

// Main function to generate wallets and encrypt private keys
const main = () => {
  // Generate a new mnemonic phrase (or replace with your actual seed phrase)
  const mnemonic = generateMnemonic();
  console.log(`Generated Mnemonic: ${mnemonic}\n`);

  // Generate the wallets from the mnemonic
  const wallets = generateWalletsFromMnemonic(mnemonic);

  // Generate a secret phrase for encryption
  const secretPhrase = "0x18faaafe7b8f8315f68df6a14115223878a03e02";

  // Output the wallets and encrypted private keys
  let output = '';
  wallets.forEach((wallet, index) => {
    const encryptedPrivateKey = encrypt(wallet.privateKey, secretPhrase);
    output += `WALLET_ADDRESS${index + 1}= ${wallet.address}\nPRIVATE_KEY${index + 1}= ${encryptedPrivateKey}\n`;
  });


  console.log(output);
};

// Uncomment the following line to run the main function
main();
