require("dotenv").config();
const Web3 = require("web3");
const {
  abi: erc20Abi,
} = require("@openzeppelin/contracts/build/contracts/ERC20.json");

const web3 = new Web3(process.env.RPC_URL);
const tokenAddress = process.env.TOKEN_ADDRESS; // Contract address of the token to transfer
const recipientAddress = process.env.RECIPIENT_ADDRESS; // Address that will receive all tokens

//wallets and PKS
const walletAddress1 = process.env.WALLET_ADDRESS1;
const privateKey1 = process.env.PRIVATE_KEY1;
const walletAddress2 = process.env.WALLET_ADDRESS2;
const privateKey2 = process.env.PRIVATE_KEY2;
const walletAddress3 = process.env.WALLET_ADDRESS3;
const privateKey3 = process.env.PRIVATE_KEY3;
const walletAddress4 = process.env.WALLET_ADDRESS4;
const privateKey4 = process.env.PRIVATE_KEY4;
const walletAddress5 = process.env.WALLET_ADDRESS5;
const privateKey5 = process.env.PRIVATE_KEY5;
const walletAddress6 = process.env.WALLET_ADDRESS6;
const privateKey6 = process.env.PRIVATE_KEY6;
const walletAddress7 = process.env.WALLET_ADDRESS7;
const privateKey7 = process.env.PRIVATE_KEY7;
const walletAddress8 = process.env.WALLET_ADDRESS8;
const privateKey8 = process.env.PRIVATE_KEY8;
const walletAddress9 = process.env.WALLET_ADDRESS9;
const privateKey9 = process.env.PRIVATE_KEY9;
const walletAddress10 = process.env.WALLET_ADDRESS10;
const privateKey10 = process.env.PRIVATE_KEY10;
const walletAddress11 = process.env.WALLET_ADDRESS11;
const privateKey11 = process.env.PRIVATE_KEY11;
const walletAddress12 = process.env.WALLET_ADDRESS12;
const privateKey12 = process.env.PRIVATE_KEY12;
const walletAddress13 = process.env.WALLET_ADDRESS13;
const privateKey13 = process.env.PRIVATE_KEY13;
const walletAddress14 = process.env.WALLET_ADDRESS14;
const privateKey14 = process.env.PRIVATE_KEY14;
const walletAddress15 = process.env.WALLET_ADDRESS15;
const privateKey15 = process.env.PRIVATE_KEY15;
const walletAddress16 = process.env.WALLET_ADDRESS16;
const privateKey16 = process.env.PRIVATE_KEY16;
const walletAddress17 = process.env.WALLET_ADDRESS17;
const privateKey17 = process.env.PRIVATE_KEY17;
const walletAddress18 = process.env.WALLET_ADDRESS18;
const privateKey18 = process.env.PRIVATE_KEY18;
const walletAddress19 = process.env.WALLET_ADDRESS19;
const privateKey19 = process.env.PRIVATE_KEY19;
const walletAddress20 = process.env.WALLET_ADDRESS20;
const privateKey20 = process.env.PRIVATE_KEY20;
const walletAddress21 = process.env.WALLET_ADDRESS21;
const privateKey21 = process.env.PRIVATE_KEY21;
const walletAddress22 = process.env.WALLET_ADDRESS22;
const privateKey22 = process.env.PRIVATE_KEY22;
const walletAddress23 = process.env.WALLET_ADDRESS23;
const privateKey23 = process.env.PRIVATE_KEY23;
const walletAddress24 = process.env.WALLET_ADDRESS24;
const privateKey24 = process.env.PRIVATE_KEY24;
const walletAddress25 = process.env.WALLET_ADDRESS25;
const privateKey25 = process.env.PRIVATE_KEY25;
const walletAddress26 = process.env.WALLET_ADDRESS26;
const privateKey26 = process.env.PRIVATE_KEY26;
const walletAddress27 = process.env.WALLET_ADDRESS27;
const privateKey27 = process.env.PRIVATE_KEY27;
const walletAddress28 = process.env.WALLET_ADDRESS28;
const privateKey28 = process.env.PRIVATE_KEY28;
const walletAddress29 = process.env.WALLET_ADDRESS29;
const privateKey29 = process.env.PRIVATE_KEY29;
const walletAddress30 = process.env.WALLET_ADDRESS30;
const privateKey30 = process.env.PRIVATE_KEY30;



const tokenContract = new web3.eth.Contract(erc20Abi, tokenAddress);

const walletsAndKeys = [
  {
    wallet: walletAddress1,
    pk: privateKey1,
  },
  {
    wallet: walletAddress2,
    pk: privateKey2,
  },
  {
    wallet: walletAddress3,
    pk: privateKey3,
  },
  {
    wallet: walletAddress4,
    pk: privateKey4,
  },
  {
    wallet: walletAddress5,
    pk: privateKey5,
  },
  {
    wallet: walletAddress6,
    pk: privateKey6,
  },
  {
    wallet: walletAddress7,
    pk: privateKey7,
  },
  {
    wallet: walletAddress8,
    pk: privateKey8,
  },
  {
    wallet: walletAddress9,
    pk: privateKey9,
  },
  {
    wallet: walletAddress10,
    pk: privateKey10,
  },
  {
    wallet: walletAddress11,
    pk: privateKey11,
  },
  {
    wallet: walletAddress12,
    pk: privateKey12,
  },
  {
    wallet: walletAddress13,
    pk: privateKey13,
  },
  {
    wallet: walletAddress14,
    pk: privateKey14,
  },
  {
    wallet: walletAddress15,
    pk: privateKey15,
  },
  {
    wallet: walletAddress16,
    pk: privateKey16,
  },
  {
    wallet: walletAddress17,
    pk: privateKey17,
  },
  {
    wallet: walletAddress18,
    pk: privateKey18,
  },
  {
    wallet: walletAddress19,
    pk: privateKey19,
  },
  {
    wallet: walletAddress20,
    pk: privateKey20,
  },
  {
    wallet: walletAddress21,
    pk: privateKey21,
  },
  {
    wallet: walletAddress22,
    pk: privateKey22,
  },
  {
    wallet: walletAddress23,
    pk: privateKey23,
  },
  {
    wallet: walletAddress24,
    pk: privateKey24,
  },
  {
    wallet: walletAddress25,
    pk: privateKey25,
  },
  {
    wallet: walletAddress26,
    pk: privateKey26,
  },
  {
    wallet: walletAddress27,
    pk: privateKey27,
  },
  {
    wallet: walletAddress28,
    pk: privateKey28,
  },
  {
    wallet: walletAddress29,
    pk: privateKey29,
  },
  {
    wallet: walletAddress30,
    pk: privateKey30,
  }

];

const transferTokens = async (walletAddress, privateKey) => {
  try {
    console.log(`Checking token balance for wallet: ${walletAddress}`);

    // Check token balance
    let balance;
    try {
      balance = await tokenContract.methods.balanceOf(walletAddress).call();
    } catch (e) {
      console.error("Error fetching token balance:", e);
      return;
    }

    if (web3.utils.toBN(balance).isZero()) {
      console.log("No tokens to transfer.");
      return;
    }

    console.log(`Token balance: ${balance}`);

    // Check allowance
    let allowance;
    try {
      allowance = await tokenContract.methods.allowance(walletAddress, recipientAddress).call();
    } catch (e) {
      console.error("Error checking token allowance:", e);
      return;
    }

    // Remove 0x prefix from private key if present
    const cleanedPrivateKey = privateKey.startsWith('0x') ? privateKey.slice(2) : privateKey;

    if (web3.utils.toBN(allowance).lt(web3.utils.toBN(balance))) {
      console.log("Insufficient allowance. Approving token transfer...");

      try {
        const approveTx = tokenContract.methods.approve(recipientAddress, balance);
        const gas = await approveTx.estimateGas({ from: walletAddress });
        const gasPrice = await web3.eth.getGasPrice();

        const data = approveTx.encodeABI();
        const nonce = await web3.eth.getTransactionCount(walletAddress);

        const signedApproveTx = await web3.eth.accounts.signTransaction(
          {
            to: tokenAddress,
            data,
            gas,
            gasPrice,
            nonce,
            chainId: 250, // Change chainId if necessary
          },
          cleanedPrivateKey
        );

        try {
          const approveReceipt = await web3.eth.sendSignedTransaction(signedApproveTx.rawTransaction);
          console.log("Approval transaction receipt:", approveReceipt);
        } catch (e) {
          console.error("Error sending signed approval transaction:", e);
          return;
        }
      } catch (e) {
        console.error("Error signing approval transaction:", e);
        return;
      }
    }

    // Transfer the token balance to the recipient address
    console.log(`Transferring ${balance} tokens to ${recipientAddress}`);

    try {
      const transferTx = tokenContract.methods.transfer(recipientAddress, balance);
      const gas = await transferTx.estimateGas({ from: walletAddress });
      const gasPrice = await web3.eth.getGasPrice();

      const data = transferTx.encodeABI();
      const nonce = await web3.eth.getTransactionCount(walletAddress);

      const signedTransferTx = await web3.eth.accounts.signTransaction(
        {
          to: tokenAddress,
          data,
          gas,
          gasPrice,
          nonce,
          chainId: 250, // Change chainId if necessary
        },
        cleanedPrivateKey
      );

      try {
        const transferReceipt = await web3.eth.sendSignedTransaction(signedTransferTx.rawTransaction);
        console.log("Transfer transaction receipt:", transferReceipt);
      } catch (e) {
        console.error("Error sending signed transfer transaction:", e);
      }
    } catch (e) {
      console.error("Error signing transfer transaction:", e);
    }
  } catch (e) {
    console.error("Error during transaction:", e);
  }
};

const transferTokensFromAllWallets = async () => {
  for (const { wallet, pk } of walletsAndKeys) {
    await transferTokens(wallet, pk);
  }
};


// Start the process
transferTokensFromAllWallets();
