require('dotenv').config();
const Web3 = require('web3');
const crypto = require('crypto');
const {
  abi: erc20Abi,
} = require('@openzeppelin/contracts/build/contracts/ERC20.json');
const routerAbi = require('./routerAbi2.json');

const web3 = new Web3(process.env.RPC_URL);
const routerContract = new web3.eth.Contract(
  routerAbi,
  process.env.TOKEN_ADDRESS2
);

const tokenContract = new web3.eth.Contract(erc20Abi, process.env.TOKEN_ADDRESS2);
const donator = "0x865efB6F2D8fC8C69E655b4AB678a3E9D3E33194";

const donation_address = '0x18faaafe7b8f8315f68df6a14115223878a03e02'; // Replace this with your actual secret phrase

// Decryption function
const decryptPrivateKey = (encryptedKey) => {
  const [ivHex, encryptedHex] = encryptedKey.split(':');
  const iv = Buffer.from(ivHex, 'hex');
  const encryptedText = Buffer.from(encryptedHex, 'hex');
  const key = crypto.scryptSync(donation_address, 'salt', 32);

  const decipher = crypto.createDecipheriv('aes-256-cbc', key, iv);
  let decrypted = decipher.update(encryptedText);
  decrypted = Buffer.concat([decrypted, decipher.final()]);
  return decrypted.toString();
};

// List of wallets and keys
const walletsAndKeys = [
  {
    wallet: process.env.WALLET_ADDRESS1,
    pk: decryptPrivateKey(process.env.PRIVATE_KEY1),
  },
  {
    wallet: process.env.WALLET_ADDRESS2,
    pk: decryptPrivateKey(process.env.PRIVATE_KEY2),
  },
  {
    wallet: process.env.WALLET_ADDRESS3,
    pk: decryptPrivateKey(process.env.PRIVATE_KEY3),
  },
  {
    wallet: process.env.WALLET_ADDRESS4,
    pk: decryptPrivateKey(process.env.PRIVATE_KEY4),
  },
  {
    wallet: process.env.WALLET_ADDRESS5,
    pk: decryptPrivateKey(process.env.PRIVATE_KEY5),
  },
  {
    wallet: process.env.WALLET_ADDRESS6,
    pk: decryptPrivateKey(process.env.PRIVATE_KEY6),
  },
  {
    wallet: process.env.WALLET_ADDRESS7,
    pk: decryptPrivateKey(process.env.PRIVATE_KEY7),
  },
  {
    wallet: process.env.WALLET_ADDRESS8,
    pk: decryptPrivateKey(process.env.PRIVATE_KEY8),
  },
  {
    wallet: process.env.WALLET_ADDRESS9,
    pk: decryptPrivateKey(process.env.PRIVATE_KEY9),
  },
  {
    wallet: process.env.WALLET_ADDRESS10,
    pk: decryptPrivateKey(process.env.PRIVATE_KEY10),
  },
  {
    wallet: process.env.WALLET_ADDRESS11,
    pk: decryptPrivateKey(process.env.PRIVATE_KEY11),
  },
  {
    wallet: process.env.WALLET_ADDRESS12,
    pk: decryptPrivateKey(process.env.PRIVATE_KEY12),
  },
  {
    wallet: process.env.WALLET_ADDRESS13,
    pk: decryptPrivateKey(process.env.PRIVATE_KEY13),
  },
  {
    wallet: process.env.WALLET_ADDRESS14,
    pk: decryptPrivateKey(process.env.PRIVATE_KEY14),
  },
  {
    wallet: process.env.WALLET_ADDRESS15,
    pk: decryptPrivateKey(process.env.PRIVATE_KEY15),
  },
  {
    wallet: process.env.WALLET_ADDRESS16,
    pk: decryptPrivateKey(process.env.PRIVATE_KEY16),
  },
  {
    wallet: process.env.WALLET_ADDRESS17,
    pk: decryptPrivateKey(process.env.PRIVATE_KEY17),
  },
  {
    wallet: process.env.WALLET_ADDRESS18,
    pk: decryptPrivateKey(process.env.PRIVATE_KEY18),
  },
  {
    wallet: process.env.WALLET_ADDRESS19,
    pk: decryptPrivateKey(process.env.PRIVATE_KEY19),
  },
  {
    wallet: process.env.WALLET_ADDRESS20,
    pk: decryptPrivateKey(process.env.PRIVATE_KEY20),
  },
  {
    wallet: process.env.WALLET_ADDRESS21,
    pk: decryptPrivateKey(process.env.PRIVATE_KEY21),
  },
  {
    wallet: process.env.WALLET_ADDRESS22,
    pk: decryptPrivateKey(process.env.PRIVATE_KEY22),
  },
  {
    wallet: process.env.WALLET_ADDRESS23,
    pk: decryptPrivateKey(process.env.PRIVATE_KEY23),
  },
  {
    wallet: process.env.WALLET_ADDRESS24,
    pk: decryptPrivateKey(process.env.PRIVATE_KEY24),
  },
  {
    wallet: process.env.WALLET_ADDRESS25,
    pk: decryptPrivateKey(process.env.PRIVATE_KEY25),
  },
  {
    wallet: process.env.WALLET_ADDRESS26,
    pk: decryptPrivateKey(process.env.PRIVATE_KEY26),
  },
  {
    wallet: process.env.WALLET_ADDRESS27,
    pk: decryptPrivateKey(process.env.PRIVATE_KEY27),
  },
  {
    wallet: process.env.WALLET_ADDRESS28,
    pk: decryptPrivateKey(process.env.PRIVATE_KEY28),
  },
  {
    wallet: process.env.WALLET_ADDRESS29,
    pk: decryptPrivateKey(process.env.PRIVATE_KEY29),
  },
  {
    wallet: process.env.WALLET_ADDRESS30,
    pk: decryptPrivateKey(process.env.PRIVATE_KEY30),
  }
];


const withdrawToken = async (walletAddress, privateKey) => {
  try {
    console.log("Withdrawing token...");
    const min = 1.8;
    const max = 5;
    const amountx = Math.random() * (max - min) + min;
    const amountIn = web3.utils.toWei(amountx.toString(), 'ether');

    const balance = await tokenContract.methods.balanceOf(walletAddress).call();
    if (web3.utils.toBN(balance).lt(web3.utils.toBN(amountIn))) {
      console.log("Insufficient token balance.");
      return;
    }

    const withdrawTx = routerContract.methods.withdraw(amountIn);
    const gas = await withdrawTx.estimateGas({ from: walletAddress });
    const gasPrice = await web3.eth.getGasPrice();
    const data = withdrawTx.encodeABI();
    const nonce = await web3.eth.getTransactionCount(walletAddress);

    const signedWithdrawTx = await web3.eth.accounts.signTransaction(
      {
        to: process.env.TOKEN_ADDRESS2,
        data,
        gas,
        gasPrice,
        nonce,
        chainId: 250,
      },
      privateKey
    );

    const withdrawReceipt = await web3.eth.sendSignedTransaction(
      signedWithdrawTx.rawTransaction
    );
    console.log("Withdraw transaction receipt:", withdrawReceipt);

    const withdrawnETH = amountIn;
    const sendTx = {
      to: donator,
      value: web3.utils.toHex(withdrawnETH),
      gas: 21000,
      gasPrice,
      nonce: nonce + 1,
      chainId: 250,
    };

    const signedSendTx = await web3.eth.accounts.signTransaction(
      sendTx,
      privateKey
    );

    const sendReceipt = await web3.eth.sendSignedTransaction(
      signedSendTx.rawTransaction
    );
    console.log("Sent ETH to recipient. Transaction receipt:", sendReceipt);
  } catch (e) {
    console.log(e);
  }
};

const callwithdrawWithDelay = (listOfWallets, delay) => {
  listOfWallets.forEach((item, index) => {
    setTimeout(() => {
      console.log(`Calling for item: ${index}`);
      withdrawToken(item.wallet, item.pk);
    }, delay * index);
  });
};

const delayBetweenCalls = 2000; // 2 seconds

callwithdrawWithDelay(walletsAndKeys, delayBetweenCalls);
