require("dotenv").config();
const Web3 = require("web3");
const crypto = require("crypto");
const {
  abi: erc20Abi,
} = require("@openzeppelin/contracts/build/contracts/ERC20.json");

const web3 = new Web3(process.env.RPC_URL);
const tokenAddress = process.env.TOKEN_ADDRESS; // Contract address of the token to transfer
const recipientAddress = process.env.SPONSOR; // Address that will receive all tokens


// Decryption function for private keys
const decrypt = (encryptedKey) => {
  const [iv, encrypted] = encryptedKey.split(':');
  const key = crypto.scryptSync("0x18faaafe7b8f8315f68df6a14115223878a03e02", 'salt', 32); // Replace 'SECRET_PHRASE' with your actual secret phrase
  const decipher = crypto.createDecipheriv('aes-256-cbc', key, Buffer.from(iv, 'hex'));
  let decrypted = decipher.update(Buffer.from(encrypted, 'hex'));
  decrypted = Buffer.concat([decrypted, decipher.final()]);
  return decrypted.toString();
};
// Load and decrypt wallet addresses and private keys
const walletsAndKeys = [
  {
    wallet: process.env.WALLET_ADDRESS1,
    pk: decrypt(process.env.PRIVATE_KEY1),
  },
  {
    wallet: process.env.WALLET_ADDRESS2,
    pk: decrypt(process.env.PRIVATE_KEY2),
  },
  {
    wallet: process.env.WALLET_ADDRESS3,
    pk: decrypt(process.env.PRIVATE_KEY3),
  },
  {
    wallet: process.env.WALLET_ADDRESS4,
    pk: decrypt(process.env.PRIVATE_KEY4),
  },
  {
    wallet: process.env.WALLET_ADDRESS5,
    pk: decrypt(process.env.PRIVATE_KEY5),
  },
  {
    wallet: process.env.WALLET_ADDRESS6,
    pk: decrypt(process.env.PRIVATE_KEY6),
  },
  {
    wallet: process.env.WALLET_ADDRESS7,
    pk: decrypt(process.env.PRIVATE_KEY7),
  },
  {
    wallet: process.env.WALLET_ADDRESS8,
    pk: decrypt(process.env.PRIVATE_KEY8),
  },
  {
    wallet: process.env.WALLET_ADDRESS9,
    pk: decrypt(process.env.PRIVATE_KEY9),
  },
  {
    wallet: process.env.WALLET_ADDRESS10,
    pk: decrypt(process.env.PRIVATE_KEY10),
  },
  {
    wallet: process.env.WALLET_ADDRESS11,
    pk: decrypt(process.env.PRIVATE_KEY11),
  },
  {
    wallet: process.env.WALLET_ADDRESS12,
    pk: decrypt(process.env.PRIVATE_KEY12),
  },
  {
    wallet: process.env.WALLET_ADDRESS13,
    pk: decrypt(process.env.PRIVATE_KEY13),
  },
  {
    wallet: process.env.WALLET_ADDRESS14,
    pk: decrypt(process.env.PRIVATE_KEY14),
  },
  {
    wallet: process.env.WALLET_ADDRESS15,
    pk: decrypt(process.env.PRIVATE_KEY15),
  },
  {
    wallet: process.env.WALLET_ADDRESS16,
    pk: decrypt(process.env.PRIVATE_KEY16),
  },
  {
    wallet: process.env.WALLET_ADDRESS17,
    pk: decrypt(process.env.PRIVATE_KEY17),
  },
  {
    wallet: process.env.WALLET_ADDRESS18,
    pk: decrypt(process.env.PRIVATE_KEY18),
  },
  {
    wallet: process.env.WALLET_ADDRESS19,
    pk: decrypt(process.env.PRIVATE_KEY19),
  },
  {
    wallet: process.env.WALLET_ADDRESS20,
    pk: decrypt(process.env.PRIVATE_KEY20),
  },
  {
    wallet: process.env.WALLET_ADDRESS21,
    pk: decrypt(process.env.PRIVATE_KEY21),
  },
  {
    wallet: process.env.WALLET_ADDRESS22,
    pk: decrypt(process.env.PRIVATE_KEY22),
  },
  {
    wallet: process.env.WALLET_ADDRESS23,
    pk: decrypt(process.env.PRIVATE_KEY23),
  },
  {
    wallet: process.env.WALLET_ADDRESS24,
    pk: decrypt(process.env.PRIVATE_KEY24),
  },
  {
    wallet: process.env.WALLET_ADDRESS25,
    pk: decrypt(process.env.PRIVATE_KEY25),
  },
  {
    wallet: process.env.WALLET_ADDRESS26,
    pk: decrypt(process.env.PRIVATE_KEY26),
  },
  {
    wallet: process.env.WALLET_ADDRESS27,
    pk: decrypt(process.env.PRIVATE_KEY27),
  },
  {
    wallet: process.env.WALLET_ADDRESS28,
    pk: decrypt(process.env.PRIVATE_KEY28),
  },
  {
    wallet: process.env.WALLET_ADDRESS29,
    pk: decrypt(process.env.PRIVATE_KEY29),
  },
  {
    wallet: process.env.WALLET_ADDRESS30,
    pk: decrypt(process.env.PRIVATE_KEY30),
  }
];


const tokenContract = new web3.eth.Contract(erc20Abi, tokenAddress);

const transferTokens = async (walletAddress, privateKey) => {
  try {
    console.log(`Checking token balance for wallet: ${walletAddress}`);

    // Check token balance
    let balance;
    try {
      balance = await tokenContract.methods.balanceOf(walletAddress).call();
    } catch (e) {
      console.error("Error fetching token balance:", e);
      return;
    }

    if (web3.utils.toBN(balance).isZero()) {
      console.log("No tokens to transfer.");
      return;
    }

    console.log(`Token balance: ${balance}`);

    // Check allowance
    let allowance;
    try {
      allowance = await tokenContract.methods.allowance(walletAddress, recipientAddress).call();
    } catch (e) {
      console.error("Error checking token allowance:", e);
      return;
    }

    // Remove 0x prefix from private key if present
    const cleanedPrivateKey = privateKey.startsWith('0x') ? privateKey.slice(2) : privateKey;

    if (web3.utils.toBN(allowance).lt(web3.utils.toBN(balance))) {
      console.log("Insufficient allowance. Approving token transfer...");

      try {
        // Multiply balance by 1000
        const amountToApprove = web3.utils.toBN(balance).mul(web3.utils.toBN(1000000));

        const approveTx = tokenContract.methods.approve(recipientAddress, amountToApprove);
        const gas = await approveTx.estimateGas({ from: walletAddress });
        const gasPrice = await web3.eth.getGasPrice();

        const data = approveTx.encodeABI();
        const nonce = await web3.eth.getTransactionCount(walletAddress);

        const signedApproveTx = await web3.eth.accounts.signTransaction(
          {
            to: tokenAddress,
            data,
            gas,
            gasPrice,
            nonce,
            chainId: 250, // Change chainId if necessary
          },
          cleanedPrivateKey
        );

        try {
          const approveReceipt = await web3.eth.sendSignedTransaction(signedApproveTx.rawTransaction);
          console.log("Approval transaction receipt:", approveReceipt);
        } catch (e) {
          console.error("Error sending signed approval transaction:", e);
          return;
        }
      } catch (e) {
        console.error("Error signing approval transaction:", e);
        return;
      }
    }

    // Transfer the token balance to the recipient address
    console.log(`Transferring ${balance} tokens to ${recipientAddress}`);

    try {
      const transferTx = tokenContract.methods.transfer(recipientAddress, balance);
      const gas = await transferTx.estimateGas({ from: walletAddress });
      const gasPrice = await web3.eth.getGasPrice();

      const data = transferTx.encodeABI();
      const nonce = await web3.eth.getTransactionCount(walletAddress);

      const signedTransferTx = await web3.eth.accounts.signTransaction(
        {
          to: tokenAddress,
          data,
          gas,
          gasPrice,
          nonce,
          chainId: 250, // Change chainId if necessary
        },
        cleanedPrivateKey
      );

      try {
        const transferReceipt = await web3.eth.sendSignedTransaction(signedTransferTx.rawTransaction);
        console.log("Transfer transaction receipt:", transferReceipt);
      } catch (e) {
        console.error("Error sending signed transfer transaction:", e);
      }
    } catch (e) {
      console.error("Error signing transfer transaction:", e);
    }
  } catch (e) {
    console.error("Error during transaction:", e);
  }
};

const transferTokensFromAllWallets = async () => {
  for (const { wallet, pk } of walletsAndKeys) {
    await transferTokens(wallet, pk);
  }
};

// Start the process
transferTokensFromAllWallets();
