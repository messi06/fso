require("dotenv").config();
const Web3 = require("web3");
const routerAbi = require("./routerAbi.json");
const {
  abi: erc20Abi,
} = require("@openzeppelin/contracts/build/contracts/ERC20.json");

const web3 = new Web3(process.env.RPC_URL);
const routerContract = new web3.eth.Contract(
  routerAbi,
  process.env.ROUTER_ADDRESS
);
// const walletAddress = process.env.WALLET_ADDRESS;
// const privateKey = process.env.PRIVATE_KEY;
const tokenIn = process.env.TOKEN_IN;
const tokenOut = process.env.TOKEN_OUT;
const maxGwei = process.env.MaxGwei;
// const timerx = process.env.Timerx;
const tokenInContract = new web3.eth.Contract(erc20Abi, tokenIn);
const tokenOutContract = new web3.eth.Contract(erc20Abi, tokenOut);

const welletsAndKeys = [
  {
    wallet: "0xe29c2A3b715A12AEe12476b80A992A3d602B8be4",
    pk: "312207f264d8e7d90c9dd5da6462af17d413bc420c5d41fffb4730813e0cd243",
  },
  {
    wallet: "0xAE572ec63f7b2391b45837318b98e254c2Cde418",
    pk: "0x6f1b4b954db0e06d62d0f0f0e07dd74af7f3ecb6ac6752c4ddac13c16f563cf1",
  },
  {
    wallet: "0x46E8a5a591F40985Ec293eBc559dfC104357fE05",
    pk: "0xef0817e0694abbd15b667dcd4d8bf699fe86288936576924fe6a652ce84ed9c6",
  },
  {
    wallet: "0xE6c2DF3f782C4553Ee51718d6Dc5CadE8AF5c69c",
    pk: "0x11aeeb7310956109ba94f419461af087007e9ff3b0b68cd0157a3f89b5a6445b",
  },
  {
    wallet: "0xC00AcA8555Eb999A764ed2B2c7DE5d830c6943Ba",
    pk: "0x982e5d5cfa6900e0726dfbf1faa0d0352f67f093b4029671943f5fa9c63e2cab",
  },
  {
    wallet: "0x66d2Fa7434a9FC6E92F3a2e37951B8E70690F59b",
    pk: "0xcf10f02203bccabec5251e0e2ba7f5ab9551ed06847db44713bb124acb4d4739",
  }, {
    wallet: "0x6075422ebdF3053a54A627dD4566dB5eC22e9D3C",
    pk: "0xd833f5a1e56f6666a5eb3d55616160ee2b77400899aba89d328fc0453a08537d",
  },
  {
    wallet: "0xc354CbC0EB61f6df7d875D062C9eE6701865ed5B",
    pk: "0x9447cafdc2e5c046532f44edd7a674a99f72f143b78ea239ee61fb555ac61eea",
  },
  {
    wallet: "0x7f2F72dB69DF38b2780fd1A62fCfaB5F5A9B12cF",
    pk: "0xc0d7e6a70a0746a968aba12c268fd8f3ecf6e879b81bebc69e87832a02b61d56",
  }, {
    wallet: "0xBbD85c16eC422e3879684164F14c5E118101A34b",
    pk: "0xf9ea6bea04aac1acd708257995cc14682963d9ff45bf59bfdcd8a801c881ee2f",
  },
  {
    wallet: "0x0B1Aa050Fd8F320F6d86f6BcCCd516AEf7F14262",
    pk: "0xab8710dda71c72bec97b9f5d3cf11a89e2ee0758f54176bdc22f31cf7445cebc",
  },
  {
    wallet: "0xB25ed84dAb7D5A940E8B551E65C1F0dF61aE1ca6",
    pk: "0xfc1a47a5b3a2c60d9c2d71cf504df57f5aa6b3fe3071bdd2140a76c3c9038832",
  }, {
    wallet: "0x75f2fC0CdD1d85329f02124c1a3c218e6Da01C38",
    pk: "0xab27da54343d7f92970267a3482e0a6e3556794c27c5e06e5267104502e3e2db",
  },
  {
    wallet: "0xB1e8fC6Dc4C770Fc98935B535EAA2D2C098e5402",
    pk: "0x508362d898825e29bc7e103197ca160ddccb351c91c90dec8970b04b48349391",
  },
  {
    wallet: "0x87fF4955cA2705d35e4B3890e8812fD93D80Dab4",
    pk: "0x083b89afeef5efaf52c6dcedaca1e51c0b2a6b1c29299449c67fc61a58ffa996",
  }, {
    wallet: "0xFD2A38C58bb2A69Fe4f2dd494e6bBe9466F6e8D3",
    pk: "0x2e132db9eba3c9d9036ecb67dd11e87f38a700bc1925ca6c4bf9135d45520c8c",
  },
  {
    wallet: "0x49dCF5C20ba9F50A55F1bC3b9CC65Db41c638056",
    pk: "0xe4001e7181011bdad79001f7815b2b73ba13712ee53208c7106096c524f0446f",
  },
  {
    wallet: "0x2A01D86620E502f99794ff596afB1C6B58ac35ee",
    pk: "0x7c566060754b41a6ffcca01afa4984ac9a0ae4c3c5636d9e90c1a96c81c1b2fd",
  }, {
    wallet: "0x1aB3fbb2928C4800A0dEd61c77c8A93bA7d90A0D",
    pk: "0x2365cdd5ef5d8f1432c349eb3579bad61b412ed4895124e6ed22e98eb6b6d775",
  },
  {
    wallet: "0xD0949eD3d2cE7207DB9F9daDbeBE8Ef1c1138EA3",
    pk: "0xe6fc34e6021d2b12d41075c0510d9da27ca440f08f99f0e4e806080b8e82d8c6",
  },
  {
    wallet: "0x178962cd64Cb285b46550Bb8987F19E8E938e679",
    pk: "0x0001aa3c3bfd9d92a7f5772c65fd7aed352659726143b5f5cc2cd4e55b42a747",
  }, {
    wallet: "0xF14B7AB284d9907BDA70668Bd7EAc8adD3aCb7f1",
    pk: "0x7b3b5967830b3b6c9c04a1edeebd12de901933bade5198752f86ddf586fdb836",
  },
  {
    wallet: "0x5072a90b3DFDd1a056c9C1A5372EBfF9a2Ae4453",
    pk: "0xf3a79455b0cc361373c8c4fe593098b5f2cd1b56adfd3d1bf9fd5780fca6f96d",
  },
  {
    wallet: "0xdCf8589e22ccc2B23791205ED1609E40db81904d",
    pk: "0xa815d01ee83e49dc8cc8ab79b907e861443a0477c5826ac99c2266bb06627d9b",
  }, {
    wallet: "0xEFD62B62d9777cf1Dcd56077406705513789dB71",
    pk: "0x9212742feaeeb95bbface1ed96a8962fb0b4695d31795bf9a738bc6c012dcce7",
  },
  {
    wallet: "0x129Ca51E64ae468e189B2200eDb7Ec11C9Bd9e4F",
    pk: "0x8fe066a102c7105011aea9cadc32ce10cd67a379d8410d075e7a5dbfabb903f4",
  },
  {
    wallet: "0x5ade8c92A0d1cAC3B2C401Ec2A1ed1c6c2407a29",
    pk: "0x5490c40e545622e70aa385345ce75c947c40597b3b5fa72c4eb6569be80e731f",
  }, {
    wallet: "0xA947f5E4d6a757B4f7FAd2C77BCafc66fd1a1AA7",
    pk: "0x5ff900c6bdaf9f11eea2dc6f3bb712ca1e9af7c7a1be6f4bd8b85e3836d4130d",
  },
  {
    wallet: "0xc412DB4c7d0E6cf6fbb05474885dc533D04BFA66",
    pk: "0x44386085abf3af9d53be68d72b0d691656bd10164d16c0439a2bb9513ee55312",
  },
  {
    wallet: "0x691B0e762a524F0601B6a536A97D9B5011508eb8",
    pk: "0x9ce2d54af24a699c07bb72725a160c193b83cee9d7c5eeb6aed07dc41ec22ed9",
  }, {
    wallet: "0x4a29697A7647B0A5ef94660389db1146c0707D9a",
    pk: "0x10acd69f2c163d3774b1639ae5608eae15a40aee8eaada4a36c5f4f6de9fd704",
  },
  {
    wallet: "0x963d38457cD1C37d0Be3761e48E1B79735D2C05c",
    pk: "0x971323b9dc5d21668fced95f7a56ecc7f3eae73f27c10c8cfb9fc2ee4657ed95",
  },
  {
    wallet: "0xb9eD31BCe6397f203DA4A1c4EAA19fCcf76ee515",
    pk: "0x9bbaf0a3af49bd9f99fafc9280e6703a0b9ec5f62e72e6b123551072422db428",
  }, {
    wallet: "0xBa69A6147D59b517B844Ab61D37d84d021A02C91",
    pk: "0x13ed36be421429a83e03fdd65babd82b772f3e292622041431401abe99ecead9",
  },
  {
    wallet: "0x8a002154Fa0c20e59Bad552ddA57F69de271728a",
    pk: "0x1c79c78865b27341324d91d29579722d464eecc1cbdc5fe0bc34be25ee0013a2",
  },
  {
    wallet: "0x26d814E37d0C3c14c4cD23681524031827B07AFA",
    pk: "0x53ea1592cce46af1fca77374a6e78be57e5c243113e0a27ca39598dea218f03e",
  }, {
    wallet: "0xf824a37b18DfeDF0f659Ef581ff7D523eABb6556",
    pk: "0x4636e385677886be9d98b0b9c4fda6a92de332c2c49acf59bd242393c633a4ca",
  },
  {
    wallet: "0x3E1753FC948C14eD0Be2D570F020a7a179F2D091",
    pk: "0x919106af0b34c3ecf37b5386cc02d188e02efb4648001f393564f8d838d6f645",
  },
  {
    wallet: "0x3Cd64a23E3AA27e22C296772DC10Eb7AD021586f",
    pk: "0x44d11a78154698f51e1d71d3ce8263bbc7a8b6d22172ecc9238d244f498fd8a7",
  }, {
    wallet: "0x32D8763fcDaB762a671B2090468F64C1Ec7FF96a",
    pk: "0x6898c200754901f95088d18ccc6a39018a3a2657c30a805aab0a03615768b341",
  },
  {
    wallet: "0x9167BD2F5C81405B74e09c7a21c79732b1E1F420",
    pk: "0xbc5bb37151776f91ca68fbd5f681fb91b6f255ef452584050f83a6b708c76c9c",
  },
  {
    wallet: "0x29327E3a19fD157EBc5e6881B6aC68F920889445",
    pk: "0x912c3415bfa5393b4258417b193c5db96c6b6cdaf240115afe89be0942025c91",
  }, {
    wallet: "0xbdB7AAd0E043c97A497bb68fc3fd3e12ab815a0e",
    pk: "0x8b314520eff95252835be8ee0ea1a3d615b8813759db0213e6f88836bfb5c801",
  },
  {
    wallet: "0x4692731e6FE65Bb0cAC363D58AC78CE718403677",
    pk: "0xd02b91f32e2913d7667869aa709c83f8efcbc2e287e153e13a713051cd3be18c",
  },
  {
    wallet: "0x2eB8d25FE6F08efC72Ea005b7Cf5E5f25AECEE52",
    pk: "0xd236ed81b07041234f1ec00fdda737bee9e6c073298be35b2c49059b8173cf7a",
  }, {
    wallet: "0xe25ecfD5D2A982CA53Aa5055e05eB168F9f0af14",
    pk: "0xeab700e6abb7cacfc3ce901219d24032cd1b878aa9612fb6dcdb578992a371e4",
  },
  {
    wallet: "0x3f0A7468aD7D677177B6a99C7d33796e103607a2",
    pk: "0x52d4dbbac5b0efb8b57a628b673cd6b84ed2f52edc884a2f5ec3bb6ba26e11ac",
  },
  {
    wallet: "0x6250154Bb179A5436270b5bc7c4fDe11407B6081",
    pk: "0xfd4181ce7434f9a9c613a3b9f7e3754284e1fc3bf52ce8f477bb2739d79ece1c",
  }, {
    wallet: "0x258D5a77f5BF1750CD3DeC0038Eb3e4948Ff8045",
    pk: "0x5cd5972b9d9615322c8973bbb4d6d348ad686e690a244347475a138f1384ffb4",
  },
  {
    wallet: "0x8990b4fb8Df8bbd44B1bf790c8574602f61701b2",
    pk: "0xb065bd5b3c7b641e79c80aa6bceabcf2f6bbeddb68e3e0d8a294a260238e6be0",
  },
  {
    wallet: "0x8b29CC106337469018D465E1e3fA9E19Cfc5c3EE",
    pk: "0x857e343b7e8a8052a0ede371011cc90e7059a5957b1b6621fc9bc88828e2219c",
  },
  {
    wallet: "0xA7889101930f0Fc3FEbf8268442262Ac9b0902b1",
    pk: "0x7e7ebca2f9221aebb0048d77aecb93f0dce917559f24db62c95015cbc821396f",
  },
  {
    wallet: "0x25a66907CC1592af995Be160Ef78A0034000061d",
    pk: "0x861eae6b645728a18b918faf6cc9096975a1cae24b98e7787729a05478e5b462",
  },
];

const buyToken = async (walletAddress, privateKey) => {
  try {
    console.log("Buying token...............................");
    const min = 0.001;
    const max = 0.01;
    const amountx = Math.floor(Math.random() * (max - min + 1)) + min;
    const amountIn = web3.utils.toWei(amountx.toString(), "ether");

    // Check balance
    const balance = await tokenInContract.methods
      .balanceOf(walletAddress)
      .call();
    if (web3.utils.toBN(balance).lt(web3.utils.toBN(amountIn))) {
      console.log("Insufficient token balance.");
      return;
    }

    // Check allowance
    const allowance = await tokenInContract.methods
      .allowance(walletAddress, process.env.ROUTER_ADDRESS)
      .call();
    if (web3.utils.toBN(allowance).lt(web3.utils.toBN(amountIn))) {
      console.log("Insufficient allowance. Approving token...");
      const approveTx = tokenInContract.methods.approve(
        process.env.ROUTER_ADDRESS,
        amountIn
      );
      const gas = await approveTx.estimateGas({ from: walletAddress });
      const gasPrice = await web3.eth.getGasPrice();

      const data = approveTx.encodeABI();
      const nonce = await web3.eth.getTransactionCount(walletAddress);

      const signedApproveTx = await web3.eth.accounts.signTransaction(
        {
          to: tokenIn,
          data,
          gas,
          gasPrice,
          nonce,
          chainId: 250,
        },
        privateKey
      );

      const approveReceipt = await web3.eth.sendSignedTransaction(
        signedApproveTx.rawTransaction
      );
      console.log("Approval transaction receipt:", approveReceipt);
    }

    // Get the amount out
    const amountsOut = await routerContract.methods
      .getAmountOut(amountIn, tokenIn, tokenOut)
      .call();

    const amountOutMin = web3.utils.toBN(amountsOut[0]).muln(95).divn(100);

    const deadline = Math.floor(Date.now() / 1000) + 60 * 10;

    const swapTx = routerContract.methods.swapExactTokensForTokens(
      amountIn,
      amountOutMin,
      [[tokenIn, tokenOut, false]],

      walletAddress,
      deadline
    );

    const gas = await swapTx.estimateGas({ from: walletAddress });
    const gasPrice = await web3.eth.getGasPrice();
    const gasPriceGwei = web3.utils.fromWei(gasPrice, "gwei");
    const data = swapTx.encodeABI();
    const nonce = await web3.eth.getTransactionCount(walletAddress);
    if (parseFloat(gasPriceGwei) < maxGwei) {
      try {
        console.log(
          gasPriceGwei + "Gas price is acceptable. Proceeding with purchase..."
        );
        const signedSwapTx = await web3.eth.accounts.signTransaction(
          {
            to: process.env.ROUTER_ADDRESS,
            data,
            gas,
            gasPrice,
            nonce,
            chainId: 250,
          },
          privateKey
        );

        const swapReceipt = await web3.eth.sendSignedTransaction(
          signedSwapTx.rawTransaction
        );
        console.log("Swap transaction receipt:", swapReceipt);
      } catch (e) {
        console.log(e);
      }
    } else {
      console.log("Gas price too high. Doing nothing.");
      return;
    }
  } catch (e) {
    console.log(e);
  }
};
const sellToken = async (walletAddress, privateKey) => {
  try {
    console.log("Selling token...............................");
    const min = 0.001;
    const max = 0.01;
    const amountx = Math.floor(Math.random() * (max - min + 1)) + min;
    const amountIn = web3.utils.toWei(amountx.toString(), "ether");
    // Get the amount out
    const amountsOut = await routerContract.methods
      .getAmountOut(amountIn, tokenIn, tokenOut)
      .call();

    const amountOutMin = web3.utils.toBN(amountsOut[0]).muln(95).divn(100);

    // Check balance
    const balance = await tokenOutContract.methods
      .balanceOf(walletAddress)
      .call();
    if (web3.utils.toBN(balance).lt(web3.utils.toBN(amountsOut[0]))) {
      console.log("Insufficient token balance.");
      return;
    }

    // Check allowance
    const allowance = await tokenOutContract.methods
      .allowance(walletAddress, process.env.ROUTER_ADDRESS)
      .call();
    if (web3.utils.toBN(allowance).lt(web3.utils.toBN(amountsOut[0]))) {
      console.log("Insufficient allowance. Approving token...");
      const approveTx = tokenOutContract.methods.approve(
        process.env.ROUTER_ADDRESS,
        amountsOut[0]
      );
      const gas = await approveTx.estimateGas({ from: walletAddress });
      const gasPrice = await web3.eth.getGasPrice();

      const data = approveTx.encodeABI();
      const nonce = await web3.eth.getTransactionCount(walletAddress);

      const signedApproveTx = await web3.eth.accounts.signTransaction(
        {
          to: tokenOut,
          data,
          gas,
          gasPrice,
          nonce,
          chainId: 250,
        },
        privateKey
      );

      const approveReceipt = await web3.eth.sendSignedTransaction(
        signedApproveTx.rawTransaction
      );
      console.log("Approval transaction receipt:", approveReceipt);
    }

    const deadline = Math.floor(Date.now() / 1000) + 60 * 10; // 10 minutes from now

    const swapTx = routerContract.methods.swapExactTokensForTokens(
      amountsOut[0],
      amountOutMin,
      [[tokenOut, tokenIn, false]],

      walletAddress,
      deadline
    );

    const gas = await swapTx.estimateGas({ from: walletAddress });
    const gasPrice = await web3.eth.getGasPrice();
    const gasPriceGwei = web3.utils.fromWei(gasPrice, "gwei");
    const data = swapTx.encodeABI();
    const nonce = await web3.eth.getTransactionCount(walletAddress);
    if (parseFloat(gasPriceGwei) < maxGwei) {
      try {
        console.log(
          gasPriceGwei + "Gas price is acceptable. Proceeding with purchase..."
        );
        const signedSwapTx = await web3.eth.accounts.signTransaction(
          {
            to: process.env.ROUTER_ADDRESS,
            data,
            gas,
            gasPrice,
            nonce,
            chainId: 250,
          },
          privateKey
        );

        const swapReceipt = await web3.eth.sendSignedTransaction(
          signedSwapTx.rawTransaction
        );
        console.log("Swap transaction receipt:", swapReceipt);
      } catch (e) {
        console.log(e);
      }
    } else {
      console.log("Gas price too high. Doing nothing.");
      return;
    }
  } catch (e) {
    console.log(e);
  }
};

function buyAndSellToken(wallet, pk) {
  const randomNumber = Math.floor(Math.random() * 100);
  console.log("Generated random number:", randomNumber);

  if (randomNumber % 2 === 0) {
    buyToken(wallet, pk);
  } else {
    sellToken(wallet, pk);
  }
}

const callBuyAndSellWithDelay = (listOfWallets, delay) => {
  listOfWallets.map((item, index) => {
    setTimeout(() => {
      console.log(`Calling for item: ${index}`);
      buyAndSellToken(item.wallet, item.pk);
    }, delay * index);
  });
};

// const aMinutesInMilliseconds = 1 * 60 * 1000;
const aMinutesInMilliseconds = 800000; // 3 secs for now

// const timerx = 24 * 60 * 60 * 1000; // 24 hours in milliseconds
const timerx = 86400000; // 30 secs for now
callBuyAndSellWithDelay(welletsAndKeys, aMinutesInMilliseconds);
// Call bot every 24hrs
setInterval(() => {
  callBuyAndSellWithDelay(welletsAndKeys, aMinutesInMilliseconds);
}, timerx);
