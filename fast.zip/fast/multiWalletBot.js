require("dotenv").config();
const Web3 = require("web3");
const routerAbi = require("./routerAbi.json");
const {
  abi: erc20Abi,
} = require("@openzeppelin/contracts/build/contracts/ERC20.json");

const web3 = new Web3(process.env.RPC_URL);
const routerContract = new web3.eth.Contract(
  routerAbi,
  process.env.ROUTER_ADDRESS
);
// const walletAddress = process.env.WALLET_ADDRESS;
// const privateKey = process.env.PRIVATE_KEY;
const tokenIn = process.env.TOKEN_IN;
const tokenOut = process.env.TOKEN_OUT;
const maxGwei = process.env.MaxGwei;
const walletAddress = process.env.WALLET_ADDRESS1;
const privateKey = process.env.PRIVATE_KEY1;
const walletAddress2 = process.env.WALLET_ADDRESS2;
const privateKey2 = process.env.PRIVATE_KEY2;
const walletAddress3 = process.env.WALLET_ADDRESS3;
const privateKey3 = process.env.PRIVATE_KEY3;
// const timerx = process.env.Timerx;
const tokenInContract = new web3.eth.Contract(erc20Abi, tokenIn);
const tokenOutContract = new web3.eth.Contract(erc20Abi, tokenOut);

const welletsAndKeys = [
  {
    wallet: walletAddress,
    pk: privateKey,
  },
  {
    wallet: walletAddress2,
    pk: privateKey2,
  },
  {
    wallet: walletAddress3,
    pk: privateKey3,
  },
];

const buyToken = async (walletAddress, privateKey) => {
  try {
    console.log("Buying token...............................");
    const min = 150000;
    const max = 300000;
    const amountx = Math.floor(Math.random() * (max - min + 1)) + min;
    const amountIn = web3.utils.toWei(amountx.toString(), "ether");

    // Check balance
    const balance = await tokenInContract.methods
      .balanceOf(walletAddress)
      .call();
    if (web3.utils.toBN(balance).lt(web3.utils.toBN(amountIn))) {
      console.log("Insufficient token balance.");
      return;
    }

    // Check allowance
    const allowance = await tokenInContract.methods
      .allowance(walletAddress, process.env.ROUTER_ADDRESS)
      .call();
    if (web3.utils.toBN(allowance).lt(web3.utils.toBN(amountIn))) {
      console.log("Insufficient allowance. Approving token...");
      const approveTx = tokenInContract.methods.approve(
        process.env.ROUTER_ADDRESS,
        amountIn
      );
      const gas = await approveTx.estimateGas({ from: walletAddress });
      const gasPrice = await web3.eth.getGasPrice();

      const data = approveTx.encodeABI();
      const nonce = await web3.eth.getTransactionCount(walletAddress);

      const signedApproveTx = await web3.eth.accounts.signTransaction(
        {
          to: tokenIn,
          data,
          gas,
          gasPrice,
          nonce,
          chainId: 250,
        },
        privateKey
      );

      const approveReceipt = await web3.eth.sendSignedTransaction(
        signedApproveTx.rawTransaction
      );
      console.log("Approval transaction receipt:", approveReceipt);
    }

    // Get the amount out
    const amountsOut = await routerContract.methods
      .getAmountOut(amountIn, tokenIn, tokenOut)
      .call();

    const amountOutMin = web3.utils.toBN(amountsOut[0]).muln(95).divn(100);

    const deadline = Math.floor(Date.now() / 1000) + 60 * 10;

    const swapTx = routerContract.methods.swapExactTokensForTokens(
      amountIn,
      amountOutMin,
      [[tokenIn, tokenOut, false]],

      walletAddress,
      deadline
    );

    const gas = await swapTx.estimateGas({ from: walletAddress });
    const gasPrice = await web3.eth.getGasPrice();
    const gasPriceGwei = web3.utils.fromWei(gasPrice, "gwei");
    const data = swapTx.encodeABI();
    const nonce = await web3.eth.getTransactionCount(walletAddress);
    if (parseFloat(gasPriceGwei) < maxGwei) {
      try {
        console.log(
          gasPriceGwei + "Gas price is acceptable. Proceeding with purchase..."
        );
        const signedSwapTx = await web3.eth.accounts.signTransaction(
          {
            to: process.env.ROUTER_ADDRESS,
            data,
            gas,
            gasPrice,
            nonce,
            chainId: 250,
          },
          privateKey
        );

        const swapReceipt = await web3.eth.sendSignedTransaction(
          signedSwapTx.rawTransaction
        );
        console.log("Swap transaction receipt:", swapReceipt);
      } catch (e) {
        console.log(e);
      }
    } else {
      console.log("Gas price too high. Doing nothing.");
      return;
    }
  } catch (e) {
    console.log(e);
  }
};
const sellToken = async (walletAddress, privateKey) => {
  try {
    console.log("Selling token...............................");
    const min = 50000;
    const max = 100000;
    const amountx = Math.floor(Math.random() * (max - min + 1)) + min;
    const amountIn = web3.utils.toWei(amountx.toString(), "ether");
    // Get the amount out
    const amountsOut = await routerContract.methods
      .getAmountOut(amountIn, tokenIn, tokenOut)
      .call();

    const amountOutMin = web3.utils.toBN(amountsOut[0]).muln(95).divn(100);

    // Check balance
    const balance = await tokenOutContract.methods
      .balanceOf(walletAddress)
      .call();
    if (web3.utils.toBN(balance).lt(web3.utils.toBN(amountsOut[0]))) {
      console.log("Insufficient token balance.");
      return;
    }

    // Check allowance
    const allowance = await tokenOutContract.methods
      .allowance(walletAddress, process.env.ROUTER_ADDRESS)
      .call();
    if (web3.utils.toBN(allowance).lt(web3.utils.toBN(amountsOut[0]))) {
      console.log("Insufficient allowance. Approving token...");
      const approveTx = tokenOutContract.methods.approve(
        process.env.ROUTER_ADDRESS,
        amountsOut[0]
      );
      const gas = await approveTx.estimateGas({ from: walletAddress });
      const gasPrice = await web3.eth.getGasPrice();

      const data = approveTx.encodeABI();
      const nonce = await web3.eth.getTransactionCount(walletAddress);

      const signedApproveTx = await web3.eth.accounts.signTransaction(
        {
          to: tokenOut,
          data,
          gas,
          gasPrice,
          nonce,
          chainId: 250,
        },
        privateKey
      );

      const approveReceipt = await web3.eth.sendSignedTransaction(
        signedApproveTx.rawTransaction
      );
      console.log("Approval transaction receipt:", approveReceipt);
    }

    const deadline = Math.floor(Date.now() / 1000) + 60 * 10; // 10 minutes from now

    const swapTx = routerContract.methods.swapExactTokensForTokens(
      amountsOut[0],
      amountOutMin,
      [[tokenOut, tokenIn, false]],

      walletAddress,
      deadline
    );

    const gas = await swapTx.estimateGas({ from: walletAddress });
    const gasPrice = await web3.eth.getGasPrice();
    const gasPriceGwei = web3.utils.fromWei(gasPrice, "gwei");
    const data = swapTx.encodeABI();
    const nonce = await web3.eth.getTransactionCount(walletAddress);
    if (parseFloat(gasPriceGwei) < maxGwei) {
      try {
        console.log(
          gasPriceGwei + "Gas price is acceptable. Proceeding with purchase..."
        );
        const signedSwapTx = await web3.eth.accounts.signTransaction(
          {
            to: process.env.ROUTER_ADDRESS,
            data,
            gas,
            gasPrice,
            nonce,
            chainId: 250,
          },
          privateKey
        );

        const swapReceipt = await web3.eth.sendSignedTransaction(
          signedSwapTx.rawTransaction
        );
        console.log("Swap transaction receipt:", swapReceipt);
      } catch (e) {
        console.log(e);
      }
    } else {
      console.log("Gas price too high. Doing nothing.");
      return;
    }
  } catch (e) {
    console.log(e);
  }
};

function buyAndSellToken(wallet, pk) {
  try {
    const randomNumber = Math.floor(Math.random() * 100);
    console.log("Generated random number:", randomNumber);
    buyToken(wallet, pk);
  } catch (error) {
    console.error("Error in buyAndSellToken:", error);
  }
}

function buyAndSellToken2(wallet, pk) {
  try {
    const randomNumber = Math.floor(Math.random() * 100);
    console.log("Generated random number:", randomNumber);

    setTimeout(() => {
      try {
        sellToken(wallet, pk);
        setTimeout(() => {
          try {
            sellToken(wallet, pk);
            setTimeout(() => {
              try {
                sellToken(wallet, pk);
              } catch (error) {
                console.error("Error in the third sellToken in buyAndSellToken2:", error);
              }
            }, 5000); // Delay for 5 seconds before the third sellToken
          } catch (error) {
            console.error("Error in the second sellToken in buyAndSellToken2:", error);
          }
        }, 5000); // Delay for 5 seconds before the second sellToken
      } catch (error) {
        console.error("Error in the first sellToken in buyAndSellToken2:", error);
      }
    }, 5000); // Delay for 5 seconds before the first sellToken

  } catch (error) {
    console.error("Error in buyAndSellToken2:", error);
  }
}


const callBuyAndSellWithDelay = (listOfWallets, delay) => {
  listOfWallets.map((item, index) => {
    setTimeout(() => {
      try {
        console.log(`Calling for item: ${index}`);
        buyAndSellToken(item.wallet, item.pk);

        // Add a delay for buyAndSellToken2 after buyAndSellToken
        setTimeout(() => {
          try {
            buyAndSellToken2(item.wallet, item.pk);
          } catch (error) {
            console.error(`Error in buyAndSellToken2 for item: ${index}`, error);
          }
        }, 5000); // Adjust this delay as needed

      } catch (error) {
        console.error(`Error in buyAndSellToken for item: ${index}`, error);
      }
    }, delay * index);
  });
};


const aMinutesInMilliseconds = 20000; // 3 secs for now

// const timerx = 24 * 60 * 60 * 1000; // 24 hours in milliseconds
const timerx = 300000; // 30 secs for now

try {
  callBuyAndSellWithDelay(welletsAndKeys, aMinutesInMilliseconds);
} catch (error) {
  console.error("Error during initial call to callBuyAndSellWithDelay:", error);
}

// Call bot every 24hrs
setInterval(() => {
  try {
    callBuyAndSellWithDelay(welletsAndKeys, aMinutesInMilliseconds);
  } catch (error) {
    console.error("Error during setInterval call to callBuyAndSellWithDelay:", error);
  }
}, timerx);
