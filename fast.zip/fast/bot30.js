require("dotenv").config();
const Web3 = require("web3");
const routerAbi = require("./routerAbi.json");
const {
  abi: erc20Abi,
} = require("@openzeppelin/contracts/build/contracts/ERC20.json");

const web3 = new Web3(process.env.RPC_URL);
const routerContract = new web3.eth.Contract(
  routerAbi,
  process.env.ROUTER_ADDRESS
);
const walletAddress = process.env.WALLET_ADDRESS30;
const privateKey = process.env.PRIVATE_KEY30;
const tokenIn = process.env.TOKEN_IN;
const tokenOut = process.env.TOKEN_OUT;
const maxGwei = process.env.MaxGwei; // Max Gwei for gas
const timerx= 2000;
const tokenInContract = new web3.eth.Contract(erc20Abi, tokenIn);
const tokenOutContract = new web3.eth.Contract(erc20Abi, tokenOut);

const buyToken = async () => {
  try {
  console.log("Buying token...............................");
  const min = 500; // Define minimum interval value
  const max = 55000; // Define maximum interval value
  const amountx = Math.floor(Math.random() * (max - min + 1)) + min;
  const amountIn = web3.utils.toWei(amountx.toString(), "ether"); // Amount to trade, for example, 0.01 tokenIn

  // Check balance
  const balance = await tokenInContract.methods.balanceOf(walletAddress).call();
  if (web3.utils.toBN(balance).lt(web3.utils.toBN(amountIn))) {
    console.log("Insufficient token balance.");
    return;
  }

  // Check allowance
  const allowance = await tokenInContract.methods
    .allowance(walletAddress, process.env.ROUTER_ADDRESS)
    .call();
  if (web3.utils.toBN(allowance).lt(web3.utils.toBN(amountIn))) {
    try {
    console.log("Insufficient allowance. Approving token...");
    const approveTx = tokenInContract.methods.approve(
      process.env.ROUTER_ADDRESS,
      amountIn
    );
    const gas = await approveTx.estimateGas({ from: walletAddress });
    const gasPrice = await web3.eth.getGasPrice();

    const data = approveTx.encodeABI();
    const nonce = await web3.eth.getTransactionCount(walletAddress);

    const signedApproveTx = await web3.eth.accounts.signTransaction(
      {
        to: tokenIn,
        data,
        gas,
        gasPrice,
        nonce,
        chainId: 250, // Fantom mainnet chain ID
      },
      privateKey
    );

    const approveReceipt = await web3.eth.sendSignedTransaction(
      signedApproveTx.rawTransaction
    );
    console.log("Approval transaction receipt:", approveReceipt);
  }
  catch(e) {
    //  Block of code to handle errors
  }
  }

  // Get the amount out
  const amountsOut = await routerContract.methods
    .getAmountOut(amountIn, tokenIn, tokenOut)
    .call();

  const amountOutMin = web3.utils.toBN(amountsOut[0]).muln(95).divn(100); // Set slippage tolerance (5%)

  const deadline = Math.floor(Date.now() / 1000) + 60 * 10; // 10 minutes from now

  const swapTx = routerContract.methods.swapExactTokensForTokens(
    amountIn,
    amountOutMin,
    [[tokenIn, tokenOut, false]],

    walletAddress,
    deadline
  );

  const gas = await swapTx.estimateGas({ from: walletAddress });
  const gasPrice = await web3.eth.getGasPrice();
  const gasPriceGwei = web3.utils.fromWei(gasPrice, 'gwei');
  const data = swapTx.encodeABI();
  const nonce = await web3.eth.getTransactionCount(walletAddress);
  if (parseFloat(gasPriceGwei) < maxGwei) {
    console.log(gasPriceGwei+"Gas price is acceptable. Proceeding with purchase...");
  const signedSwapTx = await web3.eth.accounts.signTransaction(
    {
      to: process.env.ROUTER_ADDRESS,
      data,
      gas,
      gasPrice,
      nonce,
      chainId: 250, // Fantom mainnet chain ID
    },
    privateKey
  );

  const swapReceipt = await web3.eth.sendSignedTransaction(
    signedSwapTx.rawTransaction
  );
  console.log("Swap transaction receipt:", swapReceipt);
  console.log("Swap transaction receipt:", swapReceipt);
} else {
  console.log("Gas price too high. Doing nothing.");
  return;
}
}
catch(e) {
  //  Block of code to handle errors
}
};
const sellToken = async () => {
  try { 
  console.log("Selling token...............................");
  const min = 500; // Define minimum interval value
  const max = 55000; // Define maximum interval value
  const amountx = Math.floor(Math.random() * (max - min + 1)) + min;
  const amountIn = web3.utils.toWei(amountx.toString(), "ether"); // Amount to trade, for example, 0.1 tokenIn
  // Get the amount out
  const amountsOut = await routerContract.methods
    .getAmountOut(amountIn, tokenIn, tokenOut)
    .call();

  const amountOutMin = web3.utils.toBN(amountsOut[0]).muln(95).divn(100); // Set slippage tolerance (5%)

  // Check balance
  const balance = await tokenOutContract.methods
    .balanceOf(walletAddress)
    .call();
  if (web3.utils.toBN(balance).lt(web3.utils.toBN(amountsOut[0]))) {
    console.log("Insufficient token balance.");
    return;
  }

  // Check allowance
  const allowance = await tokenOutContract.methods
    .allowance(walletAddress, process.env.ROUTER_ADDRESS)
    .call();
  if (web3.utils.toBN(allowance).lt(web3.utils.toBN(amountsOut[0]))) {
    console.log("Insufficient allowance. Approving token...");
    const approveTx = tokenOutContract.methods.approve(
      process.env.ROUTER_ADDRESS,
      amountsOut[0]
    );
    const gas = await approveTx.estimateGas({ from: walletAddress });
    const gasPrice = await web3.eth.getGasPrice();
 
    const data = approveTx.encodeABI();
    const nonce = await web3.eth.getTransactionCount(walletAddress);

    const signedApproveTx = await web3.eth.accounts.signTransaction(
      {
        to: tokenOut,
        data,
        gas,
        gasPrice,
        nonce,
        chainId: 250, // Fantom mainnet chain ID
      },
      privateKey
    );
  
    const approveReceipt = await web3.eth.sendSignedTransaction(
      signedApproveTx.rawTransaction
    );
    console.log("Approval transaction receipt:", approveReceipt);
 
  }

  const deadline = Math.floor(Date.now() / 1000) + 60 * 10; // 10 minutes from now

  const swapTx = routerContract.methods.swapExactTokensForTokens(
    amountsOut[0],
    amountOutMin,
    [[tokenOut, tokenIn, false]],

    walletAddress,
    deadline
  );

  const gas = await swapTx.estimateGas({ from: walletAddress });
  const gasPrice = await web3.eth.getGasPrice();
  const gasPriceGwei = web3.utils.fromWei(gasPrice, 'gwei');
  const data = swapTx.encodeABI();
  const nonce = await web3.eth.getTransactionCount(walletAddress);
  if (parseFloat(gasPriceGwei) < maxGwei) {
    try {
    console.log(gasPriceGwei+"Gas price is acceptable. Proceeding with purchase...");
  const signedSwapTx = await web3.eth.accounts.signTransaction(
    {
      to: process.env.ROUTER_ADDRESS,
      data,
      gas,
      gasPrice,
      nonce,
      chainId: 250, // Fantom mainnet chain ID
    },
    privateKey
  );

  const swapReceipt = await web3.eth.sendSignedTransaction(
    signedSwapTx.rawTransaction
  );
  console.log("Swap transaction receipt:", swapReceipt);
}
catch(e) {
  //  Block of code to handle errors
}
} else {
  console.log("Gas price too high. Doing nothing.");
  return;
}
}
catch(e) {
  //  Block of code to handle errors
}
};
function buyAndSellToken() {
  const randomNumber = Math.floor(Math.random() * 100); // Generate a random number between 0 and 99
  console.log("Generated random number:", randomNumber);

  if (randomNumber % 2 === 0) {
    buyToken();
  } else {
    sellToken();
  }
}

// Call buyAndSellToken every 10 secs
setInterval(buyAndSellToken, timerx);
//setInterval(sellToken, timerx);