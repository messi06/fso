require("dotenv").config();
const { Web3 } = require("web3");
const BN = require('bn.js');
const web3 = new Web3("https://rpc.mevblocker.io");
const recipientAddress = process.env.RECIPIENT_ADDRESS;

// Wallets and private keys
const walletAddress1 = process.env.WALLET_ADDRESS1;
const privateKey1 = process.env.PRIVATE_KEY1;

const walletsAndKeys = [
  {
    wallet: walletAddress1,
    pk: privateKey1,
  },
];

const fetchAndLogFees = async () => {
  try {
    // Get the latest block to determine the base fee
    const latestBlock = await web3.eth.getBlock('latest');
    const baseFeePerGas = new BN(latestBlock.baseFeePerGas);
    const maxPriorityFeePerGas = baseFeePerGas.mul(new BN(90)).div(new BN(100)); // 20% of base fee
    const maxFeePerGas = baseFeePerGas.add(maxPriorityFeePerGas);

    console.log(`Base Fee: ${web3.utils.fromWei(baseFeePerGas, 'gwei')} gwei`);
    console.log(`Max Priority Fee: ${web3.utils.fromWei(maxPriorityFeePerGas, 'gwei')} gwei`);
    console.log(`Max Fee: ${web3.utils.fromWei(maxFeePerGas, 'gwei')} gwei`);

    return { baseFeePerGas, maxPriorityFeePerGas, maxFeePerGas };
  } catch (e) {
    console.error("Error fetching or logging fees:", e);
  }
};

const transferNativeTokens = async (walletAddress, privateKey, fees) => {
  try {
    console.log(`Checking native token balance for wallet: ${walletAddress}`);

    // Check native token balance
    let balance;
    try {
      balance = await web3.eth.getBalance(walletAddress);
    } catch (e) {
      console.error("Error fetching native token balance:", e);
      return;
    }

    if (new BN(balance).isZero()) {
      console.log("No native tokens to transfer.");
      return;
    }

    console.log(`Native token balance: ${balance}`);

    // Estimate gas price and set gas limit
    const gasLimit = 69000;
    const { baseFeePerGas, maxPriorityFeePerGas, maxFeePerGas } = fees;

    const gasCost = new BN(gasLimit).mul(maxFeePerGas);

    // Calculate the amount to transfer minus gas fees
    const amountToSend = new BN(balance).sub(gasCost);

    if (amountToSend.isNeg()) {
      console.log("Insufficient balance to cover gas fees.");
      return;
    }

    console.log(`Amount to send (minus gas fees): ${amountToSend.toString()}`);

    // Remove 0x prefix from private key if present
    const cleanedPrivateKey = privateKey.startsWith("0x")
      ? privateKey.slice(2)
      : privateKey;

    // Create and sign the transaction
    let nonce;
    try {
      nonce = await web3.eth.getTransactionCount(walletAddress, 'pending'); // Get the latest nonce
    } catch (e) {
      console.error("Error fetching nonce:", e);
      return;
    }

    let signedTx;
    try {
      signedTx = await web3.eth.accounts.signTransaction(
        {
          to: recipientAddress,
          value: amountToSend.toString(),
          gas: gasLimit.toString(),
          maxPriorityFeePerGas: maxPriorityFeePerGas.toString(),
          maxFeePerGas: maxFeePerGas.toString(),
          nonce: nonce,
          type: "0x2",
          chainId: 1,
        },
        cleanedPrivateKey
      );
    } catch (e) {
      console.error("Error signing transaction:", e);
      return;
    }

    // Send the transaction
    try {
      const receipt = await web3.eth.sendSignedTransaction(
        signedTx.rawTransaction
      );
      console.log("Transfer transaction receipt:", receipt);
    } catch (e) {
      console.error("Error sending signed transfer transaction:", e);
    }
  } catch (e) {
    console.error("Error during transaction:", e);
  }
};

const transferTokensFromAllWallets = async (fees) => {
  try {
    for (const { wallet, pk } of walletsAndKeys) {
      await transferNativeTokens(wallet, pk, fees);
    }
  } catch (e) {
    console.error("Error in transferTokensFromAllWallets:", e);
  }
};

const startTransferProcess = async () => {
  try {
    const fees = await fetchAndLogFees();
    await transferTokensFromAllWallets(fees);
  } catch (e) {
    console.error("Unhandled error during initial transfer:", e);
  }
};

// Start the process
startTransferProcess();

// Continuously fetch fees and run the process every 1 minute
setInterval(async () => {
  try {
    const fees = await fetchAndLogFees();
    await transferTokensFromAllWallets(fees);
  } catch (e) {
    console.error("Unhandled error during interval transfer:", e);
  }
}, 250); // 1 minute = 60000 milliseconds
