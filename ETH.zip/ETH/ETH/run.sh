#!/bin/bash
tmux new-session -d -s paaleth1 'node send.js'
tmux new-session -d -s paaleth2 'node send2.js'
tmux new-session -d -s paaleth3 'node send3.js'
tmux new-session -d -s paaleth4 'node send4.js'
tmux new-session -d -s paaleth5 'node send5.js'

